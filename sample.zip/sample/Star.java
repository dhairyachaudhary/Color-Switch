package sample;

import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.io.Serializable;
import java.net.URL;

public class Star implements Serializable {
    private transient ImageView star;
    private boolean hit;
    private transient MediaPlayer mediaPlayer;
    private static boolean soundStar=true;

    public ImageView getStarImg() {
        return star;
    }
    public void setStarImg(ImageView starImg){
        this.star=starImg;
    }

    public static boolean isSoundStar() {
        return soundStar;
    }


    public static void setSoundStar(boolean soundStar) {
        Star.soundStar = soundStar;
    }

    {
        hit=false;
        star = new ImageView();
        star.setImage(new javafx.scene.image.Image(getClass().getResourceAsStream("/asset/star.png")));
    }

    public Star(double sx, double sy, AnchorPane root){
        star.setX(sx);
        star.setY(sy);
        root.getChildren().add(star);
    }

    public boolean getHit(){
        return hit;
    }

    public void disappear(){
        hit=true;
        playStar();
        star.setImage(null);
    }

    public void move(double distance){
        this.star.setY(this.star.getY()+distance);
    }

    private void playStar(){
        if(soundStar){
            URL resource = getClass().getResource("/asset/star.wav");
            Media media = new Media(resource.toString());
            mediaPlayer = new MediaPlayer(media);
            mediaPlayer.play();
        }
    }

}
