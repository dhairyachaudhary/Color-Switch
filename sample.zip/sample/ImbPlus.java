package sample;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Shape;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

public class ImbPlus extends Obstacle {
    private transient Line l1, l2, l3, l4, l5, l6, l7, l8;
    private transient final Group g1, g2;
    private double p1,p2,p3,p4,p5,p6,p7,p8;

    public void setL1(Line l1) {
        this.l1 = l1;
    }

    public void setL2(Line l2) {
        this.l2 = l2;
    }

    public void setL3(Line l3) {
        this.l3 = l3;
    }

    public void setL4(Line l4) {
        this.l4 = l4;
    }

    public void setL5(Line l5) {
        this.l5 = l5;
    }

    public void setL6(Line l6) {
        this.l6 = l6;
    }

    public void setL7(Line l7) {
        this.l7 = l7;
    }

    public void setL8(Line l8) {
        this.l8 = l8;
    }

    public Line getL1() {
        return l1;
    }

    public Line getL2() {
        return l2;
    }

    public Line getL3() {
        return l3;
    }

    public Line getL4() {
        return l4;
    }

    public Line getL5() {
        return l5;
    }

    public Line getL6() {
        return l6;
    }

    public Line getL7() {
        return l7;
    }

    public Line getL8() {
        return l8;
    }

    public double getP1() {
        return p1;
    }

    public double getP2() {
        return p2;
    }

    public double getP3() {
        return p3;
    }

    public double getP4() {
        return p4;
    }

    public double getP5() {
        return p5;
    }

    public double getP6() {
        return p6;
    }

    public double getP7() {
        return p7;
    }

    public double getP8() {
        return p8;
    }

    public ImbPlus(AnchorPane root, Stage stage, double center_x, double center_y, GameStart.MyTimer timer, Scene scene) throws Exception {
        super(root, stage,timer,scene,"TwoPlus");
        l1=makeParts(91+center_x, 225+center_y, Color.YELLOW, 90.0f, 82, 42, 15);
        l2=makeParts(91+center_x, 173+center_y, Color.BLUEVIOLET, 90.0f, 82, 42, 15);
        l3=makeParts(64+center_x, 200+center_y, Color.AQUA, 0, 82, 42, 15);
        l8=makeParts(119+center_x, 198+center_y, Color.DEEPPINK, 0,82, 42, 15);
        l4=makeParts(222+center_x, 153+center_y, Color.BLUEVIOLET, 90.0f, 102, 42, 25);
        l5=makeParts(222+center_x, 244+center_y, Color.YELLOW, 90.0f,102, 42, 25);
        l6=makeParts(179+center_x, 198+center_y, Color.DEEPPINK, 0, 102, 42, 25);
        l7=makeParts(264+center_x, 198+center_y, Color.AQUA, 0,102, 42, 25);

        p1=l1.getLayoutY();
        p2=l2.getLayoutY();
        p3=l3.getLayoutY();
        p4=l4.getLayoutY();
        p5=l5.getLayoutY();
        p6=l6.getLayoutY();
        p7=l7.getLayoutY();
        p8=l8.getLayoutY();

        initObstacle(160, center_y+60, 162, l4.getLayoutY()+140);

        g1=new Group();
        g2=new Group();
        g1.getChildren().addAll(l1,l2,l3,l8);
        g2.getChildren().addAll(l5,l4,l7,l6);
        root.getChildren().addAll(g1,g2);

        this.start(stage);
    }

    @Override
    public double getStar(){
        return  l4.getLayoutY()-90;
    }

    @Override
    public double getColorWheel(){
        return l4.getLayoutY()+165;
    }

    public Line makeParts(double lx, double ly, Color col, float angle, float ex, float sx, float th) {
        Line ln=new Line();
        ln.setEndX(ex);
        ln.setLayoutX(lx);
        ln.setLayoutY(ly);
        ln.setStartX(sx);
        ln.setRotate(angle);
        ln.setStroke(col);
        ln.setStrokeLineCap(StrokeLineCap.ROUND);
        ln.setStrokeWidth(th);
        return ln;
    }

    @Override
    public void start(Stage stage) throws Exception {
        RotateTransition rotate1 = new RotateTransition();
        rotate1.setAxis(Rotate.Z_AXIS);
        rotate1.setByAngle(3600);
        rotate1.setCycleCount(Animation.INDEFINITE);
        rotate1.setInterpolator(Interpolator.LINEAR);
        rotate1.setDuration(Duration.millis(25000));
        rotate1.setNode(g1);
        rotate1.play();

        RotateTransition rotate2 = new RotateTransition();
        rotate2.setAxis(Rotate.Z_AXIS);
        rotate2.setByAngle(-3600);
        rotate2.setCycleCount(Animation.INDEFINITE);
        rotate2.setInterpolator(Interpolator.LINEAR);
        rotate2.setDuration(Duration.millis(25000));
        rotate2.setNode(g2);
        rotate2.play();
    }

    @Override
    public void moveObs(double distance){
        move(distance);
        l1.setLayoutY(l1.getLayoutY()+distance);
        l2.setLayoutY(l2.getLayoutY()+distance);
        l3.setLayoutY(l3.getLayoutY()+distance);
        l4.setLayoutY(l4.getLayoutY()+distance);
        l5.setLayoutY(l5.getLayoutY()+distance);
        l6.setLayoutY(l6.getLayoutY()+distance);
        l7.setLayoutY(l7.getLayoutY()+distance);
        l8.setLayoutY(l8.getLayoutY()+distance);

        p1=l1.getLayoutY();
        p2=l2.getLayoutY();
        p3=l3.getLayoutY();
        p4=l4.getLayoutY();
        p5=l5.getLayoutY();
        p6=l6.getLayoutY();
        p7=l7.getLayoutY();
        p8=l8.getLayoutY();
    }

    @Override
    public void checkCollision(javafx.scene.shape.Circle circle, Stage stage,int score,Ball b1,Player player){
        int color;

        if(circle.getFill()==Color.AQUA){
            color=1;
        }
        else if(circle.getFill()==Color.BLUEVIOLET){
            color=2;
        }
        else if(circle.getFill()==Color.DEEPPINK){
            color=3;
        }
        else{
            color=4;
        }

        //r1=aqua=color1

        if(color==4){
            semiIntersect(circle,color,l2,stage,score,b1,player);
            semiIntersect(circle,color,l3,stage,score,b1,player);
            semiIntersect(circle,color,l4,stage,score,b1,player);
            semiIntersect(circle,color,l6,stage,score,b1,player);
            semiIntersect(circle,color,l7,stage,score,b1,player);
            semiIntersect(circle,color,l8,stage,score,b1,player);
        }
        else if(color==3){
            semiIntersect(circle,color,l1,stage,score,b1,player);
            semiIntersect(circle,color,l2,stage,score,b1,player);
            semiIntersect(circle,color,l3,stage,score,b1,player);
            semiIntersect(circle,color,l4,stage,score,b1,player);
            semiIntersect(circle,color,l5,stage,score,b1,player);
            semiIntersect(circle,color,l7,stage,score,b1,player);
        }
        else if(color==2){
            semiIntersect(circle,color,l1,stage,score,b1,player);
            semiIntersect(circle,color,l3,stage,score,b1,player);
            semiIntersect(circle,color,l5,stage,score,b1,player);
            semiIntersect(circle,color,l6,stage,score,b1,player);
            semiIntersect(circle,color,l7,stage,score,b1,player);
            semiIntersect(circle,color,l8,stage,score,b1,player);
        }

        else{
            semiIntersect(circle,color,l1,stage,score,b1,player);
            semiIntersect(circle,color,l2,stage,score,b1,player);
            semiIntersect(circle,color,l4,stage,score,b1,player);
            semiIntersect(circle,color,l5,stage,score,b1,player);
            semiIntersect(circle,color,l6,stage,score,b1,player);
            semiIntersect(circle,color,l8,stage,score,b1,player);
        }
    }
}
