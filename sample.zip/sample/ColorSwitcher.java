package sample;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;

import java.io.Serializable;
import java.net.URL;
import java.util.Random;

public class ColorSwitcher implements Serializable {
    private transient ImageView colorWheel;
    private boolean hit;
    private transient  MediaPlayer mediaPlayer;
    private static boolean soundSwitcher=true;
    private final static Random ran=new Random();


    public ImageView getSwitcherImg() {
        return colorWheel;
    }
    public void setSwitcherImg(ImageView colorWheelImg){
        this.colorWheel=colorWheelImg;
    }

    public static boolean isSoundSwitcher() {
        return soundSwitcher;
    }

    public static void setSoundSwitcher(boolean soundSwitcher) {
        ColorSwitcher.soundSwitcher = soundSwitcher;
    }

    {
        hit=false;
        colorWheel = new ImageView();
        colorWheel.setImage(new Image(getClass().getResourceAsStream("/asset/colourwheel.png")));
    }

    public ColorSwitcher(double cx, double cy, AnchorPane root){
        colorWheel.setX(cx);
        colorWheel.setY(cy);
        root.getChildren().add(colorWheel);
    }

    public boolean getHit(){
        return hit;
    }

    public void disappear1(){
        hit=true;
        playSwitch();
        colorWheel.setImage(null);
    }

    public void disappear(Ball ball, Obstacle obs){
        hit=true;
        playSwitch();
        colorWheel.setImage(null);

        colorSwitch(ball, obs);
    }

    public void move(double distance){
        this.colorWheel.setY(this.colorWheel.getY()+distance);
    }


    private void playSwitch(){
        if(soundSwitcher){
            URL resource = getClass().getResource("/asset/colorswitch.wav");
            Media media = new Media(resource.toString());
            mediaPlayer = new MediaPlayer(media);
            mediaPlayer.play();
        }
    }


    private static int generateRandom(Ball ball){
        int x = ran.nextInt(4)+1;

        if(ball.getColor()== Color.AQUA){
            while(x==1){
                x=ran.nextInt(4)+1;
            }
        } else if( ball.getColor()==Color.BLUEVIOLET){
            while(x==2){
                x=ran.nextInt(4)+1;
            }
        } else if( ball.getColor()==Color.DEEPPINK){
            while(x==3){
                x=ran.nextInt(4)+1;
            }
        } else if( ball.getColor()==Color.YELLOW){
            while(x==4){
                x=ran.nextInt(4)+1;
            }
        }
        return x;
    }

    private void changeColor(Ball ball, int x){
        if(x==1){
            ball.setColor(Color.AQUA);
        } else if(x==2){
            ball.setColor(Color.BLUEVIOLET);
        } else if(x==3){
            ball.setColor(Color.DEEPPINK);
        } else{
            ball.setColor(Color.YELLOW);
        }
    }

    private void colorSwitch(Ball ball, Obstacle obs){
        int x=generateRandom(ball);
        if(obs instanceof Triangle){
            while(x==2){
                x=generateRandom(ball);
            }
        }

        ball.setBallCol(x);
        changeColor(ball, x);
    }
}
