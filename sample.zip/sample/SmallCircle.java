package sample;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Shape;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.animation.*;
import java.io.IOException;

public class SmallCircle extends Obstacle {
    private transient Arc a1, a2, a3, a4;
    private double a1Pos;
    private double a2Pos;
    private double a3Pos;
    private double a4Pos;

    public double getA1Pos() {
        return a1Pos;
    }

    public double getA2Pos() {
        return a2Pos;
    }

    public double getA3Pos() {
        return a3Pos;
    }

    public double getA4Pos() {
        return a4Pos;
    }

    public void setA1(Arc a1) {
        this.a1 = a1;
    }

    public void setA2(Arc a2) {
        this.a2 = a2;
    }

    public void setA3(Arc a3) {
        this.a3 = a3;
    }

    public void setA4(Arc a4) {
        this.a4 = a4;
    }

    public Arc getA1(){
        return a1;
    }

    public Arc getA2() {
        return a2;
    }

    public Arc getA3() {
        return a3;
    }

    public Arc getA4() {
        return a4;
    }

    public SmallCircle(AnchorPane root, Stage stage, double center_x, double center_y, GameStart.MyTimer timer, Scene scene) throws Exception {
        super(root, stage,timer,scene, "Circle");
        a1 = makeParts(center_y, 90.0f, Color.AQUA);
        a2 = makeParts(center_y, 0.0f, Color.BLUEVIOLET);
        a3 = makeParts(center_y, 270.0f, Color.DEEPPINK);
        a4 = makeParts(center_y, 180.0f, Color.YELLOW);

        a1Pos=center_y;
        a2Pos=center_y;
        a3Pos=center_y;
        a4Pos=center_y;

        initObstacle(162, center_y-25, 162, center_y+150);
        root.getChildren().addAll(a1,a2,a3,a4);
        this.start(stage);
    }

    @Override
    public double getStar() {
        return a1.getCenterY();
    }

    @Override
    public double getColorWheel(){
        return a1.getCenterY()+175;
    }

    public Arc makeParts(double centery, float startangle, Color col) {
        Arc a = new Arc();
        a.setCenterX(195);
        a.setCenterY(centery);
        a.setRadiusX(65);
        a.setRadiusY(65);
        a.setStartAngle(startangle);
        a.setLength(90.0f);
        a.setStrokeWidth(12);
        a.setFill(Color.TRANSPARENT);
        a.setStroke(col);
        return a;
    }

    public void playAnimation(Arc a) {
        Timeline animation1 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(a.startAngleProperty(), a.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(3), new KeyValue(a.startAngleProperty(), a.getStartAngle() - 360, Interpolator.LINEAR))

        );
        animation1.setCycleCount(Animation.INDEFINITE);

        animation1.play();
    }

    @Override
    public void start(Stage stage) throws Exception {
        playAnimation(a1);
        playAnimation(a2);
        playAnimation(a3);
        playAnimation(a4);
    }

    @Override
    public void moveObs(double distance){
        move(distance);
        a1.setCenterY(a1.getCenterY()+distance);
        a2.setCenterY(a2.getCenterY()+distance);
        a3.setCenterY(a3.getCenterY()+distance);
        a4.setCenterY(a4.getCenterY()+distance);

        a1Pos=a1.getCenterY();
        a2Pos=a2.getCenterY();
        a3Pos=a3.getCenterY();
        a4Pos=a4.getCenterY();
    }


    @Override
    public void checkCollision(javafx.scene.shape.Circle circle, Stage stage,int score,Ball b1,Player player) throws IOException {
        int color;

        if(circle.getFill()==Color.AQUA){
            color=1;
        } else if(circle.getFill()==Color.BLUEVIOLET){
            color=2;
        } else if(circle.getFill()==Color.DEEPPINK){
            color=3;
        } else{
            color=4;
        }

        if(color==4){
            semiIntersect(circle,color,a1,stage,score,b1,player);
            semiIntersect(circle,color,a2,stage,score,b1,player);
            semiIntersect(circle,color,a3,stage,score,b1,player);
        }

        else if(color==3){
            semiIntersect(circle,color,a1,stage,score,b1,player);
            semiIntersect(circle,color,a2,stage,score,b1,player);
            semiIntersect(circle,color,a4,stage,score,b1,player);
        }

        else if(color==2){
            semiIntersect(circle,color,a1,stage,score,b1,player);
            semiIntersect(circle,color,a3,stage,score,b1,player);
            semiIntersect(circle,color,a4,stage,score,b1,player);
        }

        else{
            semiIntersect(circle,color,a2,stage,score,b1,player);
            semiIntersect(circle,color,a3,stage,score,b1,player);
            semiIntersect(circle,color,a4,stage,score,b1,player);
        }
    }
}
