package sample;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.shape.Line;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Shape;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.animation.*;
import java.io.IOException;

public class CircPlus extends Obstacle {
    private transient Arc a1, a2, a3, a4;
    private transient Line l1, l2, l3, l4;
    private transient Group g;
    private double p1,p2,p3,p4,p5,p6,p7,p8;

    public Arc getA1() {
        return a1;
    }

    public Arc getA2() {
        return a2;
    }

    public Arc getA3() {
        return a3;
    }

    public Arc getA4() {
        return a4;
    }

    public Line getL1() {
        return l1;
    }

    public Line getL2() {
        return l2;
    }

    public Line getL3() {
        return l3;
    }

    public Line getL4() {
        return l4;
    }

    public double getP1() {
        return p1;
    }

    public double getP2() {
        return p2;
    }

    public double getP3() {
        return p3;
    }

    public double getP4() {
        return p4;
    }

    public double getP5() {
        return p5;
    }

    public double getP6() {
        return p6;
    }

    public double getP7() {
        return p7;
    }

    public double getP8() {
        return p8;
    }

    public void setA1(Arc a1) {
        this.a1 = a1;
    }

    public void setA2(Arc a2) {
        this.a2 = a2;
    }

    public void setA3(Arc a3) {
        this.a3 = a3;
    }

    public void setA4(Arc a4) {
        this.a4 = a4;
    }

    public void setL1(Line l1) {
        this.l1 = l1;
    }

    public void setL2(Line l2) {
        this.l2 = l2;
    }

    public void setL3(Line l3) {
        this.l3 = l3;
    }

    public void setL4(Line l4) {
        this.l4 = l4;
    }

    public CircPlus(AnchorPane root, Stage stage, double center_x, double center_y, GameStart.MyTimer timer, Scene scene) throws Exception {
        super(root, stage,timer,scene, "Circle");
        a1 = makeParts(center_y, 90.0f, Color.AQUA);
        a2 = makeParts(center_y, 0.0f, Color.DEEPPINK);
        a3 = makeParts(center_y, 270.0f, Color.BLUEVIOLET);
        a4 = makeParts(center_y, 180.0f, Color.YELLOW);

        l1=makeParts(center_x-130, center_y, Color.DEEPPINK, 0);
        l3=makeParts(center_x-85, center_y, Color.YELLOW, 0);
        l2=makeParts(center_x-107, center_y-25, Color.AQUA, 90.0f);
        l4=makeParts(center_x-107, 25+center_y, Color.BLUEVIOLET, 90.0f);

        p1=a1.getCenterY();
        p2=a2.getCenterY();
        p3=a3.getCenterY();
        p4=a4.getCenterY();

        p5=l1.getLayoutY();
        p6=l2.getLayoutY();
        p7=l3.getLayoutY();
        p8=l4.getLayoutY();

        initObstacle(162, center_y-25, 162, center_y+150);
        g=new Group();
        g.getChildren().addAll(l1,l3,l2,l4);
        root.getChildren().addAll(g,a1,a2,a3,a4);
        this.start(stage);
    }

    @Override
    public double getStar() {
        return a1.getCenterY();
    }

    @Override
    public double getColorWheel(){
        return a1.getCenterY()+175;
    }

    public Arc makeParts(double centery, float startangle, Color col) {
        Arc a = new Arc();
        a.setCenterX(195);
        a.setCenterY(centery);
        a.setRadiusX(130);
        a.setRadiusY(130);
        a.setStartAngle(startangle);
        a.setLength(90.0f);
        a.setStrokeWidth(20);
        a.setFill(Color.TRANSPARENT);
        a.setStroke(col);
        return a;
    }

    public Line makeParts(double lx, double ly, Color col, float angle) {
        Line ln=new Line();
        ln.setEndX(82);
        ln.setLayoutX(lx);
        ln.setLayoutY(ly);
        ln.setStartX(42);
        ln.setRotate(angle);
        ln.setStroke(col);
        ln.setStrokeLineCap(StrokeLineCap.ROUND);
        ln.setStrokeWidth(15);
        return ln;
    }

    public void playAnimation(Arc a) {
        Timeline animation1 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(a.startAngleProperty(), a.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(3), new KeyValue(a.startAngleProperty(), a.getStartAngle() - 360, Interpolator.LINEAR))

        );
        animation1.setCycleCount(Animation.INDEFINITE);

        animation1.play();
    }

    @Override
    public void start(Stage stage) throws Exception {
        playAnimation(a1);
        playAnimation(a2);
        playAnimation(a3);
        playAnimation(a4);

        RotateTransition rotate = new RotateTransition();
        rotate.setAxis(Rotate.Z_AXIS);
        rotate.setByAngle(-360);
        rotate.setInterpolator(Interpolator.LINEAR);
        rotate.setCycleCount(Animation.INDEFINITE);
        rotate.setDuration(Duration.millis(3000));
        rotate.setNode(g);
        rotate.play();
    }

    @Override
    public void moveObs(double distance){
        move(distance);
        a1.setCenterY(a1.getCenterY()+distance);
        a2.setCenterY(a2.getCenterY()+distance);
        a3.setCenterY(a3.getCenterY()+distance);
        a4.setCenterY(a4.getCenterY()+distance);
        l1.setLayoutY(l1.getLayoutY()+distance);
        l2.setLayoutY(l2.getLayoutY()+distance);
        l3.setLayoutY(l3.getLayoutY()+distance);
        l4.setLayoutY(l4.getLayoutY()+distance);

        p1=a1.getCenterY();
        p2=a2.getCenterY();
        p3=a3.getCenterY();
        p4=a4.getCenterY();

        p5=l1.getLayoutY();
        p6=l2.getLayoutY();
        p7=l3.getLayoutY();
        p8=l4.getLayoutY();
    }


    @Override
    public void checkCollision(javafx.scene.shape.Circle circle, Stage stage,int score,Ball b1,Player player) throws IOException {
        int color;

        if(circle.getFill()==Color.AQUA){
            color=1;
        } else if(circle.getFill()==Color.BLUEVIOLET){
            color=2;
        } else if(circle.getFill()==Color.DEEPPINK){
            color=3;
        } else{
            color=4;
        }

        if(color==4){
            semiIntersect(circle,color,a1,stage,score,b1,player);
            semiIntersect(circle,color,a2,stage,score,b1,player);
            semiIntersect(circle,color,a3,stage,score,b1,player);
            semiIntersect(circle,color,l2,stage,score,b1,player);
            semiIntersect(circle,color,l1,stage,score,b1,player);
            semiIntersect(circle,color,l4,stage,score,b1,player);
        }

        else if(color==3){
            semiIntersect(circle,color,a1,stage,score,b1,player);
            semiIntersect(circle,color,a3,stage,score,b1,player);
            semiIntersect(circle,color,a4,stage,score,b1,player);
            semiIntersect(circle,color,l2,stage,score,b1,player);
            semiIntersect(circle,color,l3,stage,score,b1,player);
            semiIntersect(circle,color,l4,stage,score,b1,player);
        }

        else if(color==2){
            semiIntersect(circle,color,a1,stage,score,b1,player);
            semiIntersect(circle,color,a2,stage,score,b1,player);
            semiIntersect(circle,color,a4,stage,score,b1,player);
            semiIntersect(circle,color,l2,stage,score,b1,player);
            semiIntersect(circle,color,l1,stage,score,b1,player);
            semiIntersect(circle,color,l3,stage,score,b1,player);
        }

        else{
            semiIntersect(circle,color,a2,stage,score,b1,player);
            semiIntersect(circle,color,a3,stage,score,b1,player);
            semiIntersect(circle,color,a4,stage,score,b1,player);
            semiIntersect(circle,color,l3,stage,score,b1,player);
            semiIntersect(circle,color,l1,stage,score,b1,player);
            semiIntersect(circle,color,l4,stage,score,b1,player);
        }
    }
}
