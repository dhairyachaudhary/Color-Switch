package sample;

import javafx.animation.*;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.Random;

public class ResumeSaved implements Serializable {

    private static Player p1;

    public static Player getP1() {
        return p1;
    }

    public static void setP1(Player p1) {
        ResumeSaved.p1 = p1;
    }

    @FXML
    private void ActionReturnHome (ActionEvent event) throws IOException {
        System.out.println("You clicked return home button ");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("imageRing.fxml"));
        Parent root = loader.load();
//        Parent home_page_parent= FXMLLoader.load(getClass().getResource("imageRing.fxml"));
//        FXMLLoader loader = new FXMLLoader(getClass().getResource("settings.fxml"));
        Image myImage=(Image) (loader.getController());
        myImage.play();
        Scene scene1 =new Scene(root);
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        home_stage.setScene(scene1);
        home_stage.show();
    }

    @FXML
    private void ActionPlayGame1(ActionEvent event) throws Exception {
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        readFile(event,home_stage,1);
    }

    @FXML
    public void ActionPlayGame2(ActionEvent event) throws Exception {
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        readFile(event,home_stage,2);
    }

    @FXML
    public void ActionPlayGame3(ActionEvent event) throws Exception {
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        readFile(event,home_stage,3);
    }

    @FXML
    public void ActionPlayGame4(ActionEvent event) throws Exception {
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        readFile(event,home_stage,4);
    }

    @FXML
    public void ActionPlayGame5(ActionEvent event) throws Exception {
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        readFile(event,home_stage,5);
    }

    public static void readFile(ActionEvent event,Stage home_stage,int choose) throws Exception {





        GameStart game1;
//        ObjectInputStream objectInputStream8 =new ObjectInputStream((new FileInputStream("Saved2.txt")));
//        GameStart game1=(GameStart) objectInputStream8.readObject();
        if(choose==2){
            ObjectInputStream objectInputStream =new ObjectInputStream((new FileInputStream("Saved2.txt")));
            game1=(GameStart) objectInputStream.readObject();
//        System.out.println(game1);
        }
        else if(choose==1){
            ObjectInputStream objectInputStream =new ObjectInputStream((new FileInputStream("Saved1.txt")));
            game1=(GameStart)objectInputStream.readObject();
        }
        else if(choose==3){
            ObjectInputStream objectInputStream =new ObjectInputStream((new FileInputStream("Saved3.txt")));
            game1=(GameStart) objectInputStream.readObject();
        }
        else if(choose==4){
            ObjectInputStream objectInputStream =new ObjectInputStream((new FileInputStream("Saved4.txt")));
            game1=(GameStart) objectInputStream.readObject();
        }
        else{
            ObjectInputStream objectInputStream =new ObjectInputStream((new FileInputStream("Saved5.txt")));
            game1=(GameStart) objectInputStream.readObject();
        }



        game1.setGroup(new AnchorPane());
        game1.setStage1(home_stage);
//        game1.getGroup().addEventHandler(KeyEvent );

        game1.getGroup().addEventHandler(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>() {
            public void handle( final KeyEvent keyEvent) {
                System.out.println("TESTING PRINT");
                if(keyEvent.getCode().toString().equals("SPACE")){
                    game1.getBall().playJump();
                    game1.getBall().setBallVelocity(510);
                }
                if(keyEvent.getCode().toString().equals("P")){
                    game1.getTimer().stop();
                    Parent settings_page_parent= null;

                    try {
                        settings_page_parent = FXMLLoader.load(getClass().getResource("pause.fxml"));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    Scene scenePause =new Scene(settings_page_parent);
                    Pause pause=new Pause();
                    pause.setStage(game1.getStage1(), game1.getTimer(), game1.getStage1().getScene());
                    game1.getStage1().setScene(scenePause);
                    game1.getStage1().show();
                }
            }
        });


        double old_time = System.nanoTime();

//        game1.start(game1.getStage1());
//        game1.handle();
        //Setting scoreboard
//        game1.start(home_stage);
        game1.setScoreField(new Text(game1.getScoreStr()));
        game1.getScoreField().setFont(Font.font("verdana", FontWeight.MEDIUM, FontPosture.REGULAR, 50));
        game1.getScoreField().setFill(Color.WHITE);
        game1.getScoreField().setX(25);
        game1.getScoreField().setY(75);
        System.out.println(game1);


        //Setting Background
        game1.setBackground(new ImageView());
        game1.getBackground().setImage(new javafx.scene.image.Image(GameStart.class.getResourceAsStream("/asset/galaxySpace.jpg")));//?????????
        game1.getBackground().setX(-300);
        game1.getBackground().setY(-300);
        game1.getBackground().setScaleX(1);
        game1.getBackground().setScaleY(1);

        game1.setpImage(new ImageView());
        game1.getpImage().setImage(new javafx.scene.image.Image(GameStart.class.getResourceAsStream("/asset/PImage.png")));
        game1.getpImage().setScaleX(0.3);
        game1.getpImage().setScaleY(0.3);
        game1.getpImage().setX(277);
        game1.getpImage().setY(-33);


        //set animation timer
//        Stage stage1=new Stage();
//        game1.setTimer(new GameStart.MyTimer(old_time,game1.getStage1()));
//        GameStart.MyTimer
        GameStart.MyTimer t1=game1.new MyTimer(old_time,game1.getStage1());
        game1.setTimer(t1);
        game1.getTimer().start();



        System.out.println("69696960"+game1);
        //setting the ball up

        game1.setBall( new Ball(game1.getGroup(),10) );

        game1.getBall().setBall(new Circle());
        game1.getBall().getBall().setCenterX(195.0f);
        game1.getBall().getBall().setRadius(10.0f);
        game1.getBall().getBall().setCenterY(game1.getBall().getCircle_y());

        int colSet= game1.getBall().getBallCol();
        if (colSet==1){
            game1.getBall().getBall().setFill(Color.AQUA);
        } else if (colSet==2){
            game1.getBall().getBall().setFill(Color.BLUEVIOLET);
        } else if (colSet==3){
            game1.getBall().getBall().setFill(Color.DEEPPINK);
        } else {
            game1.getBall().getBall().setFill(Color.YELLOW);
        }
        System.out.println(colSet);

        game1.getBall().setBallVelocity(0);


        game1.getGroup().getChildren().add(game1.getBackground());
        game1.getGroup().getChildren().add(game1.getpImage());




        //Obstacles Spawn and methods
        for (Obstacle obs: game1.getObList()){
            ImageView imgStar=new ImageView();
            obs.getStar1().setStarImg(imgStar);
            imgStar.setImage(new javafx.scene.image.Image(Star.class.getResourceAsStream("/asset/star.png")));
            ImageView imgSwitcher=new ImageView();
            obs.getColorSwitcher1().setSwitcherImg(imgSwitcher);
            imgSwitcher.setImage(new javafx.scene.image.Image(ColorSwitcher.class.getResourceAsStream("/asset/colourwheel.png")));
            obs.setTimer1(game1.getTimer());

            if (obs.getObsColorSwitcher().getHit()){
                imgSwitcher.setImage(null);
            }

            if (obs.getObsStar().getHit()){
                imgStar.setImage(null);
            }

            if(obs instanceof sample.Circle){
                imgStar.setX(162);
                imgStar.setY(((sample.Circle) obs).getA1Pos()-25);
                imgSwitcher.setX(162);
                imgSwitcher.setY(((sample.Circle) obs).getA1Pos()+150);
                ((sample.Circle) obs).setA1(((sample.Circle) obs).makeParts(((sample.Circle) obs).getA1Pos(),90.0f,Color.AQUA));
                ((sample.Circle) obs).setA2(((sample.Circle) obs).makeParts(((sample.Circle) obs).getA2Pos(),0.0f,Color.BLUEVIOLET));
                ((sample.Circle) obs).setA3(((sample.Circle) obs).makeParts(((sample.Circle) obs).getA3Pos(),270.0f,Color.DEEPPINK));
                ((sample.Circle) obs).setA4(((sample.Circle) obs).makeParts(((sample.Circle) obs).getA4Pos(),180.0f,Color.YELLOW));
                game1.getGroup().getChildren().addAll(((sample.Circle) obs).getA1(),((sample.Circle) obs).getA2(),((sample.Circle) obs).getA3(),((sample.Circle) obs).getA4(),imgStar,imgSwitcher);
                obs.start(game1.getStage1());
            }
            else if(obs instanceof sample.Plus){
                imgStar.setX(160);
                imgStar.setY(((Plus) obs).getL1Pos()-195);
                imgSwitcher.setX(160);
                imgSwitcher.setY(((Plus) obs).getL1Pos()+100);
                ((sample.Plus) obs).setL1(((sample.Plus) obs).makeParts(13, ((Plus) obs).getL1Pos()-20, Color.YELLOW, 0));
                ((sample.Plus) obs).setL2(((sample.Plus) obs).makeParts(69, ((Plus) obs).getL2Pos()-20, Color.AQUA, 90.0f));
                ((sample.Plus) obs).setL3(((sample.Plus) obs).makeParts(126, ((Plus) obs).getL3Pos()-20, Color.DEEPPINK, 0));
                ((sample.Plus) obs).setL4(((sample.Plus) obs).makeParts(69, ((Plus) obs).getL4Pos()-20, Color.BLUEVIOLET, 90.0f));
                Group g=new Group();
                g.getChildren().addAll(((sample.Plus) obs).getL2(),((sample.Plus) obs).getL4(),((sample.Plus) obs).getL3(),((sample.Plus) obs).getL1());
                game1.getGroup().getChildren().addAll(g,imgStar,imgSwitcher);
                RotateTransition rotate = new RotateTransition();
                rotate.setAxis(Rotate.Z_AXIS);
                rotate.setByAngle(-3600);
                rotate.setInterpolator(Interpolator.LINEAR);
                rotate.setCycleCount(Animation.INDEFINITE);
                rotate.setDuration(Duration.millis(25000));
                rotate.setNode(g);
                rotate.play();
            }
            else if(obs instanceof sample.Rhombus){
                imgStar.setX(160);
                imgStar.setY(((Rhombus) obs).getL1Pos()-40);
                imgSwitcher.setX(162);
                imgSwitcher.setY(((Rhombus) obs).getL1Pos()+320);
                ((sample.Rhombus) obs).setL1(((sample.Rhombus) obs).makeParts(-17,90,-80,0,200,(((Rhombus) obs).getL1Pos()), Color.YELLOW));
                ((sample.Rhombus) obs).setL2(((sample.Rhombus) obs).makeParts(3.5f,112,75,0,200,((Rhombus) obs).getL2Pos(),Color.AQUA));
                ((sample.Rhombus) obs).setL3(((sample.Rhombus) obs).makeParts(-40,68,0,75,200,((Rhombus) obs).getL3Pos(), Color.DEEPPINK));
                ((sample.Rhombus) obs).setL4(((sample.Rhombus) obs).makeParts(-40,70,0,-80,200,((Rhombus) obs).getL4Pos(), Color.BLUEVIOLET));
                Group g=new Group();
                g.getChildren().addAll(((sample.Rhombus) obs).getL1(),((sample.Rhombus) obs).getL2(),((sample.Rhombus) obs).getL3(),((sample.Rhombus) obs).getL4());
                game1.getGroup().getChildren().addAll(g,imgStar,imgSwitcher);
                RotateTransition rotate = new RotateTransition();
                rotate.setAxis(Rotate.Z_AXIS);
                rotate.setByAngle(3600);
                rotate.setInterpolator(Interpolator.LINEAR);
                rotate.setCycleCount(Animation.INDEFINITE);
                rotate.setDuration(Duration.millis(25000));
                rotate.setNode(g);
                rotate.play();
            }
            else if(obs instanceof sample.Triangle){
                imgStar.setX(160);
                imgStar.setY(((Triangle) obs).getPos1()+30);
                imgSwitcher.setX(162);
                imgSwitcher.setY(((Triangle) obs).getPos1()+220);

                ((Triangle) obs).setR1(new Rectangle());
                ((Triangle) obs).getR1().setHeight(150);
                ((Triangle) obs).getR1().setLayoutX(147-10);
                ((Triangle) obs).getR1().setLayoutY(((Triangle) obs).getPos1());
                ((Triangle) obs).getR1().setRotate(30);
                ((Triangle) obs).getR1().setWidth(25);
                ((Triangle) obs).getR1().setFill(Color.AQUA);

                ((Triangle) obs).setR2(new Rectangle());
                ((Triangle) obs).getR2().setHeight(150);
                ((Triangle) obs).getR2().setLayoutX(242-10);
                ((Triangle) obs).getR2().setLayoutY(((Triangle) obs).getPos2());
                ((Triangle) obs).getR2().setRotate(-30);
                ((Triangle) obs).getR2().setWidth(25);
                ((Triangle) obs).getR2().setFill(Color.DEEPPINK);

                ((Triangle) obs).setR3(new Rectangle());
                ((Triangle) obs).getR3().setHeight(150);
                ((Triangle) obs).getR3().setLayoutX(194-10);
                ((Triangle) obs).getR3().setLayoutY(((Triangle) obs).getPos3());
                ((Triangle) obs).getR3().setRotate(90);
                ((Triangle) obs).getR3().setWidth(25);
                ((Triangle) obs).getR3().setFill(Color.YELLOW);

                ((Triangle) obs).setT1(new Polygon());
                ((Triangle) obs).getT1().getPoints().addAll(-42.79129409790039, 41.90371322631836, -17.97125816345215, 40.74338150024414, -39.923545837402344, 2.566340208053589);
                ((Triangle) obs).getT1().setFill(Color.AQUA);
                ((Triangle) obs).getT1().setLayoutX(236-10);
                ((Triangle) obs).getT1().setLayoutY(((Triangle) obs).getPos4());
                ((Triangle) obs).getT1().setRotate(30);

                ((Triangle) obs).setT2(new Polygon());
                ((Triangle) obs).getT2().getPoints().addAll(-42.791290283203125, 43.75, -18.25, 37.75, -42.791290283203125, -0.5);
                ((Triangle) obs).getT2().setFill(Color.DEEPPINK);
                ((Triangle) obs).getT2().setLayoutX(250-10);
                ((Triangle) obs).getT2().setLayoutY(((Triangle) obs).getPos5());

                ((Triangle) obs).setT3(new Polygon());
                ((Triangle) obs).getT3().getPoints().addAll(-59.75, 43.5, -18.5, 43.5, -17.97125244140625, 19.5);
                ((Triangle) obs).getT3().setFill(Color.YELLOW);
                ((Triangle) obs).getT3().setLayoutX(150-10);
                ((Triangle) obs).getT3().setLayoutY(((Triangle) obs).getPos6());

                ((Triangle) obs).setT4(new Polygon());
                ((Triangle) obs).getT4().getPoints().addAll(25.0, 43.5, -18.5, 43.5, -18.5, 18.5);
                ((Triangle) obs).getT4().setFill(Color.YELLOW);
                ((Triangle) obs).getT4().setLayoutX(299-10);
                ((Triangle) obs).getT4().setLayoutY(((Triangle) obs).getPos7());

                ((Triangle) obs).setT5(new Polygon());
                ((Triangle) obs).getT5().getPoints().addAll(-54.75, 42.5, -12.97125244140625, 18.5, -31.75, 3.5);
                ((Triangle) obs).getT5().setFill(Color.AQUA);
                ((Triangle) obs).getT5().setLayoutX(145-10);
                ((Triangle) obs).getT5().setLayoutY(((Triangle) obs).getPos8());

                ((Triangle) obs).setT6(new Polygon());
                ((Triangle) obs).getT6().getPoints().addAll(-65.75, 25.25, -24.0, 49.5, -49.0, 7.25);
                ((Triangle) obs).getT6().setFill(Color.DEEPPINK);
                ((Triangle) obs).getT6().setLayoutX(348-10);
                ((Triangle) obs).getT6().setLayoutY(((Triangle) obs).getPos9());

                Group g=new Group();
                g.getChildren().addAll(((sample.Triangle) obs).getR1(),((sample.Triangle) obs).getR2(),((sample.Triangle) obs).getR3(),((sample.Triangle) obs).getT1(),((sample.Triangle) obs).getT2(),((sample.Triangle) obs).getT3(),((sample.Triangle) obs).getT4(),((sample.Triangle) obs).getT5(),((sample.Triangle) obs).getT6());
                game1.getGroup().getChildren().addAll(g, imgStar,imgSwitcher);
                RotateTransition rotate = new RotateTransition();
                rotate.setAxis(Rotate.Z_AXIS);
                rotate.setByAngle(-3600);
                rotate.setInterpolator(Interpolator.LINEAR);
                rotate.setCycleCount(Animation.INDEFINITE);
                rotate.setDuration(Duration.millis(25000));
                rotate.setNode(g);
                rotate.play();
            }
            else if(obs instanceof TwoCircle){
                imgStar.setX(160);
                imgStar.setY(game1.getBall().getCircle_y()+160);
                imgSwitcher.setX(162);
                imgSwitcher.setY(game1.getBall().getCircle_y()+320);

                ((sample.TwoCircle) obs).setB1(((sample.TwoCircle) obs).makeParts(120,((TwoCircle) obs).getP1(),90.0f,Color.AQUA));
                ((sample.TwoCircle) obs).setB2(((sample.TwoCircle) obs).makeParts(120, ((TwoCircle) obs).getP2(),0.0f,Color.BLUEVIOLET));
                ((sample.TwoCircle) obs).setB3(((sample.TwoCircle) obs).makeParts(120, ((TwoCircle) obs).getP3(),270.0f,Color.DEEPPINK));
                ((sample.TwoCircle) obs).setB4(((sample.TwoCircle) obs).makeParts(120, ((TwoCircle) obs).getP4(),180.0f,Color.YELLOW));
                ((sample.TwoCircle) obs).setB5(((sample.TwoCircle) obs).makeParts(270, ((TwoCircle) obs).getP5(),180.0f,Color.DEEPPINK));
                ((sample.TwoCircle) obs).setB6(((sample.TwoCircle) obs).makeParts(270, ((TwoCircle) obs).getP6(),90.0f,Color.BLUEVIOLET));
                ((sample.TwoCircle) obs).setB7(((sample.TwoCircle) obs).makeParts(270, ((TwoCircle) obs).getP7(),0.0f,Color.AQUA));
                ((sample.TwoCircle) obs).setB8(((sample.TwoCircle) obs).makeParts(270, ((TwoCircle) obs).getP8(),270.0f,Color.YELLOW));
                game1.getGroup().getChildren().addAll(((sample.TwoCircle) obs).getB1(),((sample.TwoCircle) obs).getB2(),((sample.TwoCircle) obs).getB3(),((sample.TwoCircle) obs).getB4(),((sample.TwoCircle) obs).getB5(),((sample.TwoCircle) obs).getB6(),((sample.TwoCircle) obs).getB7(),((sample.TwoCircle) obs).getB8(),imgStar,imgSwitcher);
                obs.start(game1.getStage1());
            } else if(obs instanceof TwoPlus){
                imgStar.setX(160);
                imgStar.setY(((TwoPlus) obs).getP1()-195);
                imgSwitcher.setX(160);
                imgSwitcher.setY(((TwoPlus) obs).getP1()+100);

                ((sample.TwoPlus) obs).setL1(((sample.TwoPlus) obs).makeParts(91, ((TwoPlus) obs).getP1(), Color.YELLOW,  90.0f));
                ((sample.TwoPlus) obs).setL2(((sample.TwoPlus) obs).makeParts(91, ((TwoPlus) obs).getP2(), Color.BLUEVIOLET,  90.0f));
                ((sample.TwoPlus) obs).setL3(((sample.TwoPlus) obs).makeParts(64, ((TwoPlus) obs).getP3(), Color.AQUA,  0.0f));
                ((sample.TwoPlus) obs).setL4(((sample.TwoPlus) obs).makeParts(202, ((TwoPlus) obs).getP4(), Color.BLUEVIOLET,  90.0f));
                ((sample.TwoPlus) obs).setL5(((sample.TwoPlus) obs).makeParts(202, ((TwoPlus) obs).getP5(), Color.YELLOW,  90.0f));
                ((sample.TwoPlus) obs).setL6(((sample.TwoPlus) obs).makeParts(174, ((TwoPlus) obs).getP6(), Color.DEEPPINK,  0.0f));
                ((sample.TwoPlus) obs).setL7(((sample.TwoPlus) obs).makeParts(229, ((TwoPlus) obs).getP6(), Color.AQUA,  0.0f));
                ((sample.TwoPlus) obs).setL8(((sample.TwoPlus) obs).makeParts(119, ((TwoPlus) obs).getP6(), Color.DEEPPINK,  0.0f));

                Group g1=new Group();
                Group g2=new Group();

                g1.getChildren().addAll(((TwoPlus) obs).getL1(),((TwoPlus) obs).getL2(),((TwoPlus) obs).getL3(),((TwoPlus) obs).getL8());
                g2.getChildren().addAll(((TwoPlus) obs).getL5(), ((TwoPlus) obs).getL4(), ((TwoPlus) obs).getL7(),((TwoPlus) obs).getL6());
                game1.getGroup().getChildren().addAll(g1,g2,imgStar,imgSwitcher);

                RotateTransition rotate1 = new RotateTransition();
                rotate1.setAxis(Rotate.Z_AXIS);
                rotate1.setByAngle(3600);
                rotate1.setCycleCount(Animation.INDEFINITE);
                rotate1.setInterpolator(Interpolator.LINEAR);
                rotate1.setDuration(Duration.millis(25000));
                rotate1.setNode(g1);
                rotate1.play();

                RotateTransition rotate2 = new RotateTransition();
                rotate2.setAxis(Rotate.Z_AXIS);
                rotate2.setByAngle(-3600);
                rotate2.setCycleCount(Animation.INDEFINITE);
                rotate2.setInterpolator(Interpolator.LINEAR);
                rotate2.setDuration(Duration.millis(25000));
                rotate2.setNode(g2);
                rotate2.play();
            } else if(obs instanceof DottedCircle){
                imgStar.setX(160);
                imgStar.setY(((DottedCircle) obs).getP1()+80);
                imgSwitcher.setX(160);
                imgSwitcher.setY(((DottedCircle) obs).getP1()+235);

                ((DottedCircle) obs).setC1(new Circle(179,((DottedCircle) obs).getP1(),10));
                ((DottedCircle) obs).getC1().setFill(Color.DEEPPINK);
                ((DottedCircle) obs).setC2(new Circle(97,((DottedCircle) obs).getP2(),10));
                ((DottedCircle) obs).getC2().setFill(Color.DEEPPINK);
                ((DottedCircle) obs).setC3(new Circle(156,((DottedCircle) obs).getP3(),10));
                ((DottedCircle) obs).getC3().setFill(Color.DEEPPINK);
                ((DottedCircle) obs).setC4(new Circle(137,((DottedCircle) obs).getP4(),10));
                ((DottedCircle) obs).getC4().setFill(Color.DEEPPINK);
                ((DottedCircle) obs).setC5(new Circle(106,((DottedCircle) obs).getP5(),10));
                ((DottedCircle) obs).getC5().setFill(Color.DEEPPINK);
                ((DottedCircle) obs).setC6(new Circle(121,((DottedCircle) obs).getP6(),10));
                ((DottedCircle) obs).getC6().setFill(Color.DEEPPINK);
                ((DottedCircle) obs).setC7(new Circle(206,((DottedCircle) obs).getP7(),10));
                ((DottedCircle) obs).getC7().setFill(Color.YELLOW);
                ((DottedCircle) obs).setC8(new Circle(233,((DottedCircle) obs).getP8(),10));
                ((DottedCircle) obs).getC8().setFill(Color.YELLOW);
                ((DottedCircle) obs).setC9(new Circle(255,((DottedCircle) obs).getP9(),10));
                ((DottedCircle) obs).getC9().setFill(Color.YELLOW);
                ((DottedCircle) obs).setC10(new Circle(292,((DottedCircle) obs).getP10(),10));
                ((DottedCircle) obs).getC10().setFill(Color.YELLOW);
                ((DottedCircle) obs).setC11(new Circle(284,((DottedCircle) obs).getP11(),10));
                ((DottedCircle) obs).getC11().setFill(Color.YELLOW);
                ((DottedCircle) obs).setC12(new Circle(271,((DottedCircle) obs).getP12(),10));
                ((DottedCircle) obs).getC12().setFill(Color.YELLOW);
                ((DottedCircle) obs).setC13(new Circle(96,((DottedCircle) obs).getP13(),10));
                ((DottedCircle) obs).getC13().setFill(Color.AQUA);
                ((DottedCircle) obs).setC14(new Circle(102,((DottedCircle) obs).getP14(),10));
                ((DottedCircle) obs).getC14().setFill(Color.AQUA);
                ((DottedCircle) obs).setC15(new Circle(114,((DottedCircle) obs).getP15(),10));
                ((DottedCircle) obs).getC15().setFill(Color.AQUA);
                ((DottedCircle) obs).setC16(new Circle(132,((DottedCircle) obs).getP16(),10));
                ((DottedCircle) obs).getC16().setFill(Color.AQUA);
                ((DottedCircle) obs).setC17(new Circle(154,((DottedCircle) obs).getP17(),10));
                ((DottedCircle) obs).getC17().setFill(Color.AQUA);
                ((DottedCircle) obs).setC18(new Circle(179,((DottedCircle) obs).getP18(),10));
                ((DottedCircle) obs).getC18().setFill(Color.AQUA);
                ((DottedCircle) obs).setC19(new Circle(294,((DottedCircle) obs).getP19(),10));
                ((DottedCircle) obs).getC19().setFill(Color.BLUEVIOLET);
                ((DottedCircle) obs).setC20(new Circle(288,((DottedCircle) obs).getP20(),10));
                ((DottedCircle) obs).getC20().setFill(Color.BLUEVIOLET);
                ((DottedCircle) obs).setC21(new Circle(276,((DottedCircle) obs).getP21(),10));
                ((DottedCircle) obs).getC21().setFill(Color.BLUEVIOLET);
                ((DottedCircle) obs).setC22(new Circle(259,((DottedCircle) obs).getP22(),10));
                ((DottedCircle) obs).getC22().setFill(Color.BLUEVIOLET);
                ((DottedCircle) obs).setC23(new Circle(234,((DottedCircle) obs).getP23(),10));
                ((DottedCircle) obs).getC23().setFill(Color.BLUEVIOLET);
                ((DottedCircle) obs).setC24(new Circle(206,((DottedCircle) obs).getP24(),10));
                ((DottedCircle) obs).getC24().setFill(Color.BLUEVIOLET);

                Group g=new Group();
                g.getChildren().addAll(((DottedCircle) obs).getC1(), ((DottedCircle) obs).getC2(), ((DottedCircle) obs).getC3(),((DottedCircle) obs).getC4(), ((DottedCircle) obs).getC5(), ((DottedCircle) obs).getC6(), ((DottedCircle) obs).getC7(), ((DottedCircle) obs).getC8(), ((DottedCircle) obs).getC9(),((DottedCircle) obs).getC10(),((DottedCircle) obs).getC11(),((DottedCircle) obs).getC12(),((DottedCircle) obs).getC13(),((DottedCircle) obs).getC14(),((DottedCircle) obs).getC15(),((DottedCircle) obs).getC16(),((DottedCircle) obs).getC17(),((DottedCircle) obs).getC18(),((DottedCircle) obs).getC19(),((DottedCircle) obs).getC20(),((DottedCircle) obs).getC21(),((DottedCircle) obs).getC22(),((DottedCircle) obs).getC23(),((DottedCircle) obs).getC24());
                game1.getGroup().getChildren().addAll(g,imgStar,imgSwitcher);

                RotateTransition rotate = new RotateTransition();
                rotate.setAxis(Rotate.Z_AXIS);
                rotate.setByAngle(-3600);
                rotate.setInterpolator(Interpolator.LINEAR);
                rotate.setCycleCount(Animation.INDEFINITE);
                rotate.setDuration(Duration.millis(25000));
                rotate.setNode(g);
                rotate.play();
            } else if(obs instanceof RevPlus){
                imgStar.setX(160);
                imgStar.setY(((RevPlus) obs).getL1Pos()-195);
                imgSwitcher.setX(160);
                imgSwitcher.setY(((RevPlus) obs).getL1Pos()+100);
                ((sample.RevPlus) obs).setL1(((sample.RevPlus) obs).makeParts(90+75, ((RevPlus) obs).getL1Pos(), Color.YELLOW, 0));
                ((sample.RevPlus) obs).setL2(((sample.RevPlus) obs).makeParts(146+75, ((RevPlus) obs).getL2Pos(), Color.AQUA, 90.0f));
                ((sample.RevPlus) obs).setL3(((sample.RevPlus) obs).makeParts(203+75, ((RevPlus) obs).getL3Pos(), Color.DEEPPINK, 0));
                ((sample.RevPlus) obs).setL4(((sample.RevPlus) obs).makeParts(146+75,  ((RevPlus) obs).getL4Pos(), Color.BLUEVIOLET, 90.0f));
                Group g=new Group();
                g.getChildren().addAll(((sample.RevPlus) obs).getL2(),((sample.RevPlus) obs).getL4(),((sample.RevPlus) obs).getL3(),((sample.RevPlus) obs).getL1());
                game1.getGroup().getChildren().addAll(g,imgStar,imgSwitcher);
                RotateTransition rotate = new RotateTransition();
                rotate.setAxis(Rotate.Z_AXIS);
                rotate.setByAngle(3600);
                rotate.setInterpolator(Interpolator.LINEAR);
                rotate.setCycleCount(Animation.INDEFINITE);
                rotate.setDuration(Duration.millis(25000));
                rotate.setNode(g);
                rotate.play();
            } else if(obs instanceof ImbPlus){
                imgStar.setX(160);
                imgStar.setY(((ImbPlus) obs).getP1()-195);
                imgSwitcher.setX(160);
                imgSwitcher.setY(((ImbPlus) obs).getP1()+100);

                ((sample.ImbPlus) obs).setL1(((sample.ImbPlus) obs).makeParts(91, ((ImbPlus) obs).getP1(), Color.YELLOW,  90.0f,82, 42, 15));
                ((sample.ImbPlus) obs).setL2(((sample.ImbPlus) obs).makeParts(91, ((ImbPlus) obs).getP2(), Color.BLUEVIOLET,  90.0f, 82, 42, 15));
                ((sample.ImbPlus) obs).setL3(((sample.ImbPlus) obs).makeParts(64, ((ImbPlus) obs).getP3(), Color.AQUA,  0.0f, 82, 42, 15));
                ((sample.ImbPlus) obs).setL4(((sample.ImbPlus) obs).makeParts(222, ((ImbPlus) obs).getP4(), Color.BLUEVIOLET,  90.0f, 102, 42, 25));
                ((sample.ImbPlus) obs).setL5(((sample.ImbPlus) obs).makeParts(222, ((ImbPlus) obs).getP5(), Color.YELLOW,  90.0f, 102, 42, 25));
                ((sample.ImbPlus) obs).setL6(((sample.ImbPlus) obs).makeParts(179, ((ImbPlus) obs).getP6(), Color.DEEPPINK,  0.0f, 102, 42, 25));
                ((sample.ImbPlus) obs).setL7(((sample.ImbPlus) obs).makeParts(264, ((ImbPlus) obs).getP6(), Color.AQUA,  0.0f, 102, 42, 25));
                ((sample.ImbPlus) obs).setL8(((sample.ImbPlus) obs).makeParts(119, ((ImbPlus) obs).getP6(), Color.DEEPPINK,  0.0f, 82, 42, 15));

                Group g1=new Group();
                Group g2=new Group();

                g1.getChildren().addAll(((ImbPlus) obs).getL1(),((ImbPlus) obs).getL2(),((ImbPlus) obs).getL3(),((ImbPlus) obs).getL8());
                g2.getChildren().addAll(((ImbPlus) obs).getL5(), ((ImbPlus) obs).getL4(), ((ImbPlus) obs).getL7(),((ImbPlus) obs).getL6());
                game1.getGroup().getChildren().addAll(g1,g2,imgStar,imgSwitcher);

                RotateTransition rotate1 = new RotateTransition();
                rotate1.setAxis(Rotate.Z_AXIS);
                rotate1.setByAngle(3600);
                rotate1.setCycleCount(Animation.INDEFINITE);
                rotate1.setInterpolator(Interpolator.LINEAR);
                rotate1.setDuration(Duration.millis(25000));
                rotate1.setNode(g1);
                rotate1.play();

                RotateTransition rotate2 = new RotateTransition();
                rotate2.setAxis(Rotate.Z_AXIS);
                rotate2.setByAngle(-3600);
                rotate2.setCycleCount(Animation.INDEFINITE);
                rotate2.setInterpolator(Interpolator.LINEAR);
                rotate2.setDuration(Duration.millis(25000));
                rotate2.setNode(g2);
                rotate2.play();
            } else if(obs instanceof ImbCircle){
                imgStar.setX(160);
                imgStar.setY(((ImbCircle) obs).getP1()-100);
                imgSwitcher.setX(162);
                imgSwitcher.setY(((ImbCircle) obs).getP1()+130);

                ((sample.ImbCircle) obs).setB1(((sample.ImbCircle) obs).makeParts(120,((ImbCircle) obs).getP1(),90.0f,Color.AQUA, 60, 8));
                ((sample.ImbCircle) obs).setB2(((sample.ImbCircle) obs).makeParts(120, ((ImbCircle) obs).getP2(),0.0f,Color.BLUEVIOLET, 60, 8));
                ((sample.ImbCircle) obs).setB3(((sample.ImbCircle) obs).makeParts(120, ((ImbCircle) obs).getP3(),270.0f,Color.DEEPPINK, 60, 8));
                ((sample.ImbCircle) obs).setB4(((sample.ImbCircle) obs).makeParts(120, ((ImbCircle) obs).getP4(),180.0f,Color.YELLOW, 60, 8));
                ((sample.ImbCircle) obs).setB5(((sample.ImbCircle) obs).makeParts(270, ((ImbCircle) obs).getP5(),180.0f,Color.DEEPPINK, 82, 12));
                ((sample.ImbCircle) obs).setB6(((sample.ImbCircle) obs).makeParts(270, ((ImbCircle) obs).getP6(),90.0f,Color.BLUEVIOLET, 82, 12));
                ((sample.ImbCircle) obs).setB7(((sample.ImbCircle) obs).makeParts(270, ((ImbCircle) obs).getP7(),0.0f,Color.AQUA, 82, 12));
                ((sample.ImbCircle) obs).setB8(((sample.ImbCircle) obs).makeParts(270, ((ImbCircle) obs).getP8(),270.0f,Color.YELLOW, 82, 12));
                game1.getGroup().getChildren().addAll(((sample.ImbCircle) obs).getB1(),((sample.ImbCircle) obs).getB2(),((sample.ImbCircle) obs).getB3(),((sample.ImbCircle) obs).getB4(),((sample.ImbCircle) obs).getB5(),((sample.ImbCircle) obs).getB6(),((sample.ImbCircle) obs).getB7(),((sample.ImbCircle) obs).getB8(),imgStar,imgSwitcher);
                obs.start(game1.getStage1());
            } else if(obs instanceof ThreeCirc){
                imgStar.setX(162);
                imgStar.setY(((sample.ThreeCirc) obs).getP1()-25);
                imgSwitcher.setX(162);
                imgSwitcher.setY(((sample.ThreeCirc) obs).getP1()+150);

                ((sample.ThreeCirc) obs).setA1(((sample.ThreeCirc) obs).makeParts(((sample.ThreeCirc) obs).getP1(),180.0f,100,Color.DEEPPINK));
                ((sample.ThreeCirc) obs).setA2(((sample.ThreeCirc) obs).makeParts(((sample.ThreeCirc) obs).getP1(),90.0f,100,Color.BLUEVIOLET));
                ((sample.ThreeCirc) obs).setA3(((sample.ThreeCirc) obs).makeParts(((sample.ThreeCirc) obs).getP1(),0.0f,100,Color.AQUA));
                ((sample.ThreeCirc) obs).setA4(((sample.ThreeCirc) obs).makeParts(((sample.ThreeCirc) obs).getP1(),270.0f,100,Color.YELLOW));
                ((sample.ThreeCirc) obs).setA5(((sample.ThreeCirc) obs).makeParts(((sample.ThreeCirc) obs).getP1(),90.0f,75,Color.AQUA));
                ((sample.ThreeCirc) obs).setA6(((sample.ThreeCirc) obs).makeParts(((sample.ThreeCirc) obs).getP1(),0.0f,75,Color.BLUEVIOLET));
                ((sample.ThreeCirc) obs).setA7(((sample.ThreeCirc) obs).makeParts(((sample.ThreeCirc) obs).getP1(),270.0f,75,Color.DEEPPINK));
                ((sample.ThreeCirc) obs).setA8(((sample.ThreeCirc) obs).makeParts(((sample.ThreeCirc) obs).getP1(),180.0f,75,Color.YELLOW));
                ((sample.ThreeCirc) obs).setA9(((sample.ThreeCirc) obs).makeParts(((sample.ThreeCirc) obs).getP1(),90.0f,125,Color.AQUA));
                ((sample.ThreeCirc) obs).setA10(((sample.ThreeCirc) obs).makeParts(((sample.ThreeCirc) obs).getP1(),0.0f,125,Color.BLUEVIOLET));
                ((sample.ThreeCirc) obs).setA11(((sample.ThreeCirc) obs).makeParts(((sample.ThreeCirc) obs).getP1(),270.0f,125,Color.DEEPPINK));
                ((sample.ThreeCirc) obs).setA12(((sample.ThreeCirc) obs).makeParts(((sample.ThreeCirc) obs).getP1(),180.0f,125,Color.YELLOW));
                game1.getGroup().getChildren().addAll(((sample.ThreeCirc) obs).getA1(),((sample.ThreeCirc) obs).getA2(),((sample.ThreeCirc) obs).getA3(),((sample.ThreeCirc) obs).getA4(),((sample.ThreeCirc) obs).getA5(),((sample.ThreeCirc) obs).getA6(),((sample.ThreeCirc) obs).getA7(),((sample.ThreeCirc) obs).getA8(),((sample.ThreeCirc) obs).getA9(),((sample.ThreeCirc) obs).getA10(),((sample.ThreeCirc) obs).getA11(),((sample.ThreeCirc) obs).getA12(),imgStar,imgSwitcher);
                obs.start(game1.getStage1());
            } else if(obs instanceof VertCirc){
                imgStar.setX(160);
                imgStar.setY(((VertCirc) obs).getP1()-150);
                imgSwitcher.setX(162);
                imgSwitcher.setY(((VertCirc) obs).getP1()+240);

                ((sample.VertCirc) obs).setB1(((sample.VertCirc) obs).makeParts(200,((VertCirc) obs).getP1(),90.0f,Color.AQUA));
                ((sample.VertCirc) obs).setB2(((sample.VertCirc) obs).makeParts(200, ((VertCirc) obs).getP2(),0.0f,Color.BLUEVIOLET));
                ((sample.VertCirc) obs).setB3(((sample.VertCirc) obs).makeParts(200, ((VertCirc) obs).getP3(),270.0f,Color.DEEPPINK));
                ((sample.VertCirc) obs).setB4(((sample.VertCirc) obs).makeParts(200, ((VertCirc) obs).getP4(),180.0f,Color.YELLOW));
                ((sample.VertCirc) obs).setB5(((sample.VertCirc) obs).makeParts(200, ((VertCirc) obs).getP5(),180.0f,Color.BLUEVIOLET));
                ((sample.VertCirc) obs).setB6(((sample.VertCirc) obs).makeParts(200, ((VertCirc) obs).getP6(),90.0f,Color.DEEPPINK));
                ((sample.VertCirc) obs).setB7(((sample.VertCirc) obs).makeParts(200, ((VertCirc) obs).getP7(),0.0f,Color.YELLOW));
                ((sample.VertCirc) obs).setB8(((sample.VertCirc) obs).makeParts(200, ((VertCirc) obs).getP8(),270.0f,Color.AQUA));
                game1.getGroup().getChildren().addAll(((sample.VertCirc) obs).getB1(),((sample.VertCirc) obs).getB2(),((sample.VertCirc) obs).getB3(),((sample.VertCirc) obs).getB4(),((sample.VertCirc) obs).getB5(),((sample.VertCirc) obs).getB6(),((sample.VertCirc) obs).getB7(),((sample.VertCirc) obs).getB8(),imgStar,imgSwitcher);
                obs.start(game1.getStage1());
            } else if(obs instanceof SmallCircle){
                imgStar.setX(162);
                imgStar.setY(((sample.SmallCircle) obs).getA1Pos()-25);
                imgSwitcher.setX(162);
                imgSwitcher.setY(((sample.SmallCircle) obs).getA1Pos()+150);
                ((sample.SmallCircle) obs).setA1(((sample.SmallCircle) obs).makeParts(((sample.SmallCircle) obs).getA1Pos(),90.0f,Color.AQUA));
                ((sample.SmallCircle) obs).setA2(((sample.SmallCircle) obs).makeParts(((sample.SmallCircle) obs).getA2Pos(),0.0f,Color.BLUEVIOLET));
                ((sample.SmallCircle) obs).setA3(((sample.SmallCircle) obs).makeParts(((sample.SmallCircle) obs).getA3Pos(),270.0f,Color.DEEPPINK));
                ((sample.SmallCircle) obs).setA4(((sample.SmallCircle) obs).makeParts(((sample.SmallCircle) obs).getA4Pos(),180.0f,Color.YELLOW));
                game1.getGroup().getChildren().addAll(((sample.SmallCircle) obs).getA1(),((sample.SmallCircle) obs).getA2(),((sample.SmallCircle) obs).getA3(),((sample.SmallCircle) obs).getA4(),imgStar,imgSwitcher);
                obs.start(game1.getStage1());
            } else if(obs instanceof CircPlus){
                imgStar.setX(162);
                imgStar.setY(((sample.CircPlus) obs).getP1()-25);
                imgSwitcher.setX(162);
                imgSwitcher.setY(((sample.CircPlus) obs).getP1()+150);

                ((sample.CircPlus) obs).setA1(((sample.CircPlus) obs).makeParts(((sample.CircPlus) obs).getP1(),90.0f,Color.AQUA));
                ((sample.CircPlus) obs).setA2(((sample.CircPlus) obs).makeParts(((sample.CircPlus) obs).getP2(),0.0f,Color.DEEPPINK));
                ((sample.CircPlus) obs).setA3(((sample.CircPlus) obs).makeParts(((sample.CircPlus) obs).getP3(),270.0f,Color.BLUEVIOLET));
                ((sample.CircPlus) obs).setA4(((sample.CircPlus) obs).makeParts(((sample.CircPlus) obs).getP4(),180.0f,Color.YELLOW));
                game1.getGroup().getChildren().addAll(((sample.CircPlus) obs).getA1(),((sample.CircPlus) obs).getA2(),((sample.CircPlus) obs).getA3(),((sample.CircPlus) obs).getA4(),imgStar,imgSwitcher);
                ((sample.CircPlus) obs).setL1(((sample.CircPlus) obs).makeParts(65, ((CircPlus) obs).getP5()+20, Color.DEEPPINK, 0));
                ((sample.CircPlus) obs).setL2(((sample.CircPlus) obs).makeParts(110, ((CircPlus) obs).getP6()+45, Color.YELLOW, 0.0f));
                ((sample.CircPlus) obs).setL3(((sample.CircPlus) obs).makeParts(88, ((CircPlus) obs).getP7()-5, Color.AQUA, 90.0f));
                ((sample.CircPlus) obs).setL4(((sample.CircPlus) obs).makeParts(88, ((CircPlus) obs).getP8()+21, Color.BLUEVIOLET, 90.0f));
                Group g=new Group();
                g.getChildren().addAll(((sample.CircPlus) obs).getL4(),((sample.CircPlus) obs).getL3(),((sample.CircPlus) obs).getL1(),((sample.CircPlus) obs).getL2());
                game1.getGroup().getChildren().add(g);
                RotateTransition rotate = new RotateTransition();
                rotate.setAxis(Rotate.Z_AXIS);
                rotate.setByAngle(-360);
                rotate.setInterpolator(Interpolator.LINEAR);
                rotate.setCycleCount(Animation.INDEFINITE);
                rotate.setDuration(Duration.millis(3000));
                rotate.setNode(g);

                Timeline animation1 = new Timeline(
                        new KeyFrame(Duration.ZERO, new KeyValue(((sample.CircPlus) obs).getA1().startAngleProperty(), ((sample.CircPlus) obs).getA1().getStartAngle(), Interpolator.LINEAR)),
                        new KeyFrame(Duration.seconds(3), new KeyValue(((sample.CircPlus) obs).getA1().startAngleProperty(), ((sample.CircPlus) obs).getA1().getStartAngle() - 360, Interpolator.LINEAR))

                );
                animation1.setCycleCount(Animation.INDEFINITE);

                Timeline animation2 = new Timeline(
                        new KeyFrame(Duration.ZERO, new KeyValue(((sample.CircPlus) obs).getA2().startAngleProperty(), ((sample.CircPlus) obs).getA2().getStartAngle(), Interpolator.LINEAR)),
                        new KeyFrame(Duration.seconds(3), new KeyValue(((sample.CircPlus) obs).getA2().startAngleProperty(), ((sample.CircPlus) obs).getA2().getStartAngle() - 360, Interpolator.LINEAR))

                );
                animation2.setCycleCount(Animation.INDEFINITE);

                Timeline animation3 = new Timeline(
                        new KeyFrame(Duration.ZERO, new KeyValue(((sample.CircPlus) obs).getA3().startAngleProperty(), ((sample.CircPlus) obs).getA3().getStartAngle(), Interpolator.LINEAR)),
                        new KeyFrame(Duration.seconds(3), new KeyValue(((sample.CircPlus) obs).getA3().startAngleProperty(), ((sample.CircPlus) obs).getA3().getStartAngle() - 360, Interpolator.LINEAR))

                );
                animation3.setCycleCount(Animation.INDEFINITE);

                Timeline animation4 = new Timeline(
                        new KeyFrame(Duration.ZERO, new KeyValue(((sample.CircPlus) obs).getA4().startAngleProperty(), ((sample.CircPlus) obs).getA4().getStartAngle(), Interpolator.LINEAR)),
                        new KeyFrame(Duration.seconds(3), new KeyValue(((sample.CircPlus) obs).getA4().startAngleProperty(), ((sample.CircPlus) obs).getA4().getStartAngle() - 360, Interpolator.LINEAR))

                );
                animation4.setCycleCount(Animation.INDEFINITE);

                animation1.play();
                animation2.play();
                animation3.play();
                animation4.play();

                rotate.play();
            }
        }

        //Adding stuff to the scene
        game1.setStage1((Stage)((Node)event.getSource()).getScene().getWindow());

        game1.getGroup().getChildren().add(game1.getScoreField());
        game1.getGroup().getChildren().add(game1.getBall().getBall());
//        game1.getGroup().getChildren().add(game1.getBall());
        var scene =new Scene(game1.getGroup(),400,600);
        game1.getStage1().setScene(scene);
        game1.getGroup().requestFocus();
        game1.getStage1().requestFocus();
        game1.getStage1().show();



    }


}
