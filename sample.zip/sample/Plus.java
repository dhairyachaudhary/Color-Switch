package sample;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Shape;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.io.Serializable;

public class Plus extends Obstacle implements Serializable {
    private transient Line l1, l2, l3, l4;
    private transient final Group g;
    private transient static Stage stage2;
    private transient static GameStart.MyTimer timer1;
    private transient static Scene scene1;

    private double l1Pos;
    private double l2Pos;
    private double l3Pos;
    private double l4Pos;

    public double getL1Pos() {
        return l1Pos;
    }

    public double getL2Pos() {
        return l2Pos;
    }

    public double getL3Pos() {
        return l3Pos;
    }

    public double getL4Pos() {
        return l4Pos;
    }


    public Line getL1() {
        return l1;
    }

    public void setL1(Line l1) {
        this.l1 = l1;
    }

    public Line getL2() {
        return l2;
    }

    public void setL2(Line l2) {
        this.l2 = l2;
    }

    public Line getL3() {
        return l3;
    }

    public void setL3(Line l3) {
        this.l3 = l3;
    }

    public Line getL4() {
        return l4;
    }

    public void setL4(Line l4) {
        this.l4 = l4;
    }

    public Plus(AnchorPane root, Stage stage, double center_x, double center_y, GameStart.MyTimer timer, Scene scene) throws Exception {
        super(root, stage,timer,scene,"Plus");
        stage2=stage;
        scene1=scene;
        timer1=timer;

        l1=makeParts(90+center_x, 192+center_y, Color.YELLOW, 0);
        l2=makeParts(146+center_x, 139+center_y, Color.AQUA, 90.0f);
        l3=makeParts(203+center_x, 192+center_y, Color.DEEPPINK, 0);
        l4=makeParts(146+center_x, 246+center_y, Color.BLUEVIOLET, 90.0f);
        l1Pos=center_y;
        l2Pos=center_y;
        l3Pos=center_y;
        l4Pos=center_y;

        initObstacle(160, center_y+30, 162, center_y+336);

        g=new Group();
        g.getChildren().addAll(l2,l4, l1, l3);
        root.getChildren().add(g);

        this.start(stage);
    }

    @Override
    public double getStar(){
        return  l4.getLayoutY()-195;
    }

    @Override
    public double getColorWheel(){
        return l4.getLayoutY()+120;
    }

    public Line makeParts(double lx, double ly, Color col, float angle) {
        Line ln=new Line();
        ln.setEndX(100);
        ln.setLayoutX(lx);
        ln.setLayoutY(ly);
        ln.setStartX(12);
        ln.setRotate(angle);
        ln.setStroke(col);
        ln.setStrokeLineCap(StrokeLineCap.ROUND);
        ln.setStrokeWidth(25);
        return ln;
    }

    @Override
    public void start(Stage stage) throws Exception {
        RotateTransition rotate = new RotateTransition();
        rotate.setAxis(Rotate.Z_AXIS);
        rotate.setByAngle(-3600);
        rotate.setInterpolator(Interpolator.LINEAR);
        rotate.setCycleCount(Animation.INDEFINITE);
        rotate.setDuration(Duration.millis(25000));
        rotate.setNode(g);
        rotate.play();
    }

    @Override
    public void moveObs(double distance){
        move(distance);
        l1.setLayoutY(l1.getLayoutY()+distance);
        l2.setLayoutY(l2.getLayoutY()+distance);
        l3.setLayoutY(l3.getLayoutY()+distance);
        l4.setLayoutY(l4.getLayoutY()+distance);
        l1Pos=l1.getLayoutY();
        l2Pos=l2.getLayoutY();
        l3Pos=l3.getLayoutY();
        l4Pos=l4.getLayoutY();

    }

    @Override
    public void checkCollision(javafx.scene.shape.Circle circle, Stage stage,int score,Ball b1,Player player){
        int color;

        if(circle.getFill()==Color.AQUA){
            color=1;
        }
        else if(circle.getFill()==Color.BLUEVIOLET){
            color=2;
        }
        else if(circle.getFill()==Color.DEEPPINK){
            color=3;
        }
        else{
            color=4;
        }

        //r1=aqua=color1

        if(color==4){
            semiIntersect(circle,color,l2,stage,score, b1,player);
            semiIntersect(circle,color,l3,stage,score, b1,player);
            semiIntersect(circle,color,l4,stage,score, b1,player);
        }
        else if(color==3){
            semiIntersect(circle,color,l2,stage,score, b1,player);
            semiIntersect(circle,color,l1,stage,score, b1,player);
            semiIntersect(circle,color,l4,stage,score, b1,player);
        }
        else if(color==2){
            semiIntersect(circle,color,l2,stage,score, b1,player);
            semiIntersect(circle,color,l1,stage,score, b1,player);
            semiIntersect(circle,color,l3,stage,score, b1,player);
        }

        else{
            semiIntersect(circle,color,l3,stage,score, b1,player);
            semiIntersect(circle,color,l1,stage,score, b1,player);
            semiIntersect(circle,color,l4,stage,score, b1,player);

        }
    }
}
