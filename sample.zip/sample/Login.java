package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;

public class Login {

    @FXML
    public void ActionDhairya(ActionEvent event) throws IOException, ClassNotFoundException {
        System.out.println("You clicked return home button ");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("imageRing.fxml"));
        Parent root = loader.load();
        Image myImage=(Image) (loader.getController());
        myImage.getWelcomeMsg().setText("Welcome Dhairya!");
//        myImage.setWelcomeMsg(playerWelcome);
        myImage.play();
        Player Dhairya=new Player("Dhairya");
        myImage.setPlayer(Dhairya);
        ResumeSaved.setP1(Dhairya);
        Scene scene1 =new Scene(root);
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        home_stage.setScene(scene1);
        home_stage.show();
    }
    @FXML
    public void ActionJishnu(ActionEvent event) throws IOException, ClassNotFoundException {
        System.out.println("You clicked return home button ");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("imageRing.fxml"));
        Parent root = loader.load();
        Image myImage=(Image) (loader.getController());
        myImage.getWelcomeMsg().setText("Welcome Jishnu!");
//        myImage.setWelcomeMsg(playerWelcome);
        myImage.play();
        Player Jishnu=new Player("Jishnu");
        myImage.setPlayer(Jishnu);
        ResumeSaved.setP1(Jishnu);
        Scene scene1 =new Scene(root);
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        home_stage.setScene(scene1);
        home_stage.show();
    }
    @FXML
    public void ActionIshika(ActionEvent event) throws IOException, ClassNotFoundException {
        System.out.println("You clicked return home button ");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("imageRing.fxml"));
        Parent root = loader.load();
        Image myImage=(Image) (loader.getController());
        myImage.getWelcomeMsg().setText("Welcome Ishika!");
//        myImage.setWelcomeMsg(playerWelcome);
        myImage.play();
        Player Ishika=new Player("Ishika");
        myImage.setPlayer(Ishika);
        ResumeSaved.setP1(Ishika);
        Scene scene1 =new Scene(root);
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        home_stage.setScene(scene1);
        home_stage.show();
    }
    @FXML
    public void ActionRishit(ActionEvent event) throws IOException, ClassNotFoundException {
        System.out.println("You clicked return home button ");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("imageRing.fxml"));
        Parent root = loader.load();
        Image myImage=(Image) (loader.getController());
//        Text playerWelcome=new Text("Welcome Rishit!");
        myImage.getWelcomeMsg().setText("Welcome Rishit!");
        myImage.play();
        Player Rishit=new Player("Rishit");
        myImage.setPlayer(Rishit);
        ResumeSaved.setP1(Rishit);
        Scene scene1 =new Scene(root);
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        home_stage.setScene(scene1);
        home_stage.show();
    }
    @FXML
    public void ActionKrish(ActionEvent event) throws IOException, ClassNotFoundException {
        System.out.println("You clicked return home button ");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("imageRing.fxml"));
        Parent root = loader.load();
        Image myImage=(Image) (loader.getController());
        myImage.getWelcomeMsg().setText("Welcome Krish!");
//        myImage.setWelcomeMsg(playerWelcome);
        myImage.play();
        Player Krish=new Player("Krish");
        myImage.setPlayer(Krish);
        ResumeSaved.setP1(Krish);
        Scene scene1 =new Scene(root);
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        home_stage.setScene(scene1);
        home_stage.show();
    }
}
