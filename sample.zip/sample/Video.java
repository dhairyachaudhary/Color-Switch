package sample;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.stage.Stage;

import java.awt.*;
import java.io.File;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;
import java.time.Duration;

public class Video extends Application {

    @FXML
    private MediaView mv;

    private MediaPlayer mediaPlayer;

    @FXML
    private Button Play;

    @FXML
    public void ActionPlayVideo(ActionEvent event){
//        mediaPlayer.setStartTime(new Duration(0));
        mediaPlayer.play();
    }


    @Override
    public void start(Stage stage) throws Exception {
        String path = "/Users/rishitgupta/Downloads/APVideo.mp4";
        Media media = new Media(path);

        //Instantiating MediaPlayer class
        mediaPlayer = new MediaPlayer(media);

        //Instantiating MediaView class
        MediaView mediaView = new MediaView(mediaPlayer);
        mv.setFitHeight(600);
        mv.setFitWidth(400);
        mv.setMediaPlayer(mediaPlayer);

        //by setting this property to true, the Video will be played
//        mediaPlayer.setAutoPlay(true);
//        Group root = new Group();
//        root.getChildren().add(mediaView);
//        Scene scene = new Scene(root,500,400);
//        stage.setScene(scene);
//        stage.setTitle("Playing video");
//        stage.show();




    }
    public static void main(String[] args) {
        launch(args);
    }
}
