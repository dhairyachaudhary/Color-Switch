package sample;

import javafx.animation.AnimationTimer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.*;

public class Pause implements Serializable {

    private transient  static Stage stage1;
    private transient  static GameStart.MyTimer timer1;
    private transient  static Scene scene1;
    private static GameStart myGame;
    private Player player;


    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public static void setMyGame(GameStart myGame1){
        myGame=myGame1;
    }
    public static void setStage(Stage stage, GameStart.MyTimer timer,Scene scene){
        stage1=stage;
        timer1=timer;
        scene1=scene;
//        myGame=myGame1;
    }

    @FXML
    private void ActionReturnHome(ActionEvent event) throws IOException {
        System.out.println("You clicked return home button ");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("imageRing.fxml"));
        Parent root = loader.load();
        Image myImage=(Image) (loader.getController());
        myImage.play();
        Scene scene1 =new Scene(root);
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        home_stage.setScene(scene1);
        home_stage.show();
    }

    @FXML
    private void ActionResume(ActionEvent event) throws Exception {
        timer1.setT_old(System.nanoTime());
        timer1.start();
        stage1.setScene(scene1);
        stage1.show();

    }

    @FXML
    private void ActionSaveGame(ActionEvent event) throws IOException {
        System.out.println(myGame.getBall().getCenter());

        for (Obstacle obs:myGame.getObList()){
            System.out.println(obs.getObsStar());
        }
    writeToFile(myGame);
        FXMLLoader loader = new FXMLLoader(getClass().getResource("imageRing.fxml"));
        Parent root = loader.load();
        Image myImage=(Image) (loader.getController());
        myImage.play();
        Scene scene1 =new Scene(root);
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        home_stage.setScene(scene1);
        home_stage.show();

    }

    public static void writeToFile(GameStart g1) throws IOException {
        if(GameStart.getPlayer().getName().equals("Jishnu")){
            ObjectOutputStream objectOutputStream1=new ObjectOutputStream(new FileOutputStream("Saved2.txt"));
//        ObjectOutputStream objectOutputStream=new ObjectOutputStream(new FileOutputStream("Saved2.txt"));
            objectOutputStream1.writeObject(g1);
        }
        else if(GameStart.getPlayer().getName().equals("Dhairya")){
            ObjectOutputStream objectOutputStream1=new ObjectOutputStream(new FileOutputStream("Saved1.txt"));
//        ObjectOutputStream objectOutputStream=new ObjectOutputStream(new FileOutputStream("Saved2.txt"));
            objectOutputStream1.writeObject(g1);
        }
        else if(GameStart.getPlayer().getName().equals("Ishika")){
            ObjectOutputStream objectOutputStream1=new ObjectOutputStream(new FileOutputStream("Saved3.txt"));
//        ObjectOutputStream objectOutputStream=new ObjectOutputStream(new FileOutputStream("Saved2.txt"));
            objectOutputStream1.writeObject(g1);
        }
        else if(GameStart.getPlayer().getName().equals("Rishit")){
            ObjectOutputStream objectOutputStream1=new ObjectOutputStream(new FileOutputStream("Saved4.txt"));
//        ObjectOutputStream objectOutputStream=new ObjectOutputStream(new FileOutputStream("Saved2.txt"));
            objectOutputStream1.writeObject(g1);
        }
        else{
            ObjectOutputStream objectOutputStream1=new ObjectOutputStream(new FileOutputStream("Saved5.txt"));
            objectOutputStream1.writeObject(g1);
        }




    }

    public static void readFile() throws IOException, ClassNotFoundException {
        if(GameStart.getPlayer().getName().equals("Jishnu")){
            ObjectInputStream objectInputStream =new ObjectInputStream((new FileInputStream("Saved2.txt")));
            GameStart game1=(GameStart) objectInputStream.readObject();
//        System.out.println(game1);
        }
        else if(GameStart.getPlayer().getName().equals("Dhairya")){
            ObjectInputStream objectInputStream =new ObjectInputStream((new FileInputStream("Saved1.txt")));
            GameStart game1=(GameStart) objectInputStream.readObject();
        }
        else if(GameStart.getPlayer().getName().equals("Ishika")){
            ObjectInputStream objectInputStream =new ObjectInputStream((new FileInputStream("Saved3.txt")));
            GameStart game1=(GameStart) objectInputStream.readObject();
        }
        else if(GameStart.getPlayer().getName().equals("Rishit")){
            ObjectInputStream objectInputStream =new ObjectInputStream((new FileInputStream("Saved4.txt")));
            GameStart game1=(GameStart) objectInputStream.readObject();
        }
        else{
            ObjectInputStream objectInputStream =new ObjectInputStream((new FileInputStream("Saved5.txt")));
            GameStart game1=(GameStart) objectInputStream.readObject();
        }

    }

}

