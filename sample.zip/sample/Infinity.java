package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.ImageView;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.io.Serializable;

public class Infinity implements Serializable {


    private static Player player;

    @FXML
    private transient Button ClassicButton;


    @FXML
    private transient Button ReturnHome;

    @FXML
    private transient Button FireFlyButton;

    private static boolean isFrenzy;

    public static boolean isIsFrenzy() {
        return isFrenzy;
    }

    public static void setIsFrenzy(boolean isFrenzy) {
        Infinity.isFrenzy = isFrenzy;
    }

    public static Player getPlayer() {
        return player;
    }

    public static void setPlayer(Player player1) {
        player = player1;
    }

    @FXML
    private void goBackFromInfinityAction(ActionEvent event) throws IOException {
        System.out.println("You clicked return home button ");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("imageRing.fxml"));
        Parent root = loader.load();
//        Parent home_page_parent= FXMLLoader.load(getClass().getResource("imageRing.fxml"));
//        FXMLLoader loader = new FXMLLoader(getClass().getResource("settings.fxml"));
        Image myImage=(Image) (loader.getController());
        myImage.play();
        Scene scene1 =new Scene(root);
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        home_stage.setScene(scene1);
        home_stage.show();
    }
    @FXML
    private void ActionClassic(ActionEvent event) throws Exception {
        isFrenzy=false;
        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        GameStart game1=new GameStart(10,false,player);
        Pause.setMyGame(game1);
        Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
        some_stage.setScene(a);
        some_stage.show();

    }

    @FXML
    private void ActionFrenzy(ActionEvent event) throws Exception {
    isFrenzy=true;
        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        GameStart game1=new GameStart(10,false,player);
        Pause.setMyGame(game1);
        Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
        some_stage.setScene(a);
        some_stage.show();
    }


}
