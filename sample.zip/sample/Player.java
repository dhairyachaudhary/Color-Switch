package sample;

import java.io.Serializable;

public class Player implements Serializable {


//    private GameStart game;
//    private sample.Image homescreen;

    private String name;
    private int totalStars;
    private int bestScore;
    private int gameScore;

    @Override
    public String toString() {
        return "Player{" +
                "name='" + name + '\'' +
                ", totalStars=" + totalStars +
                ", bestScore=" + bestScore +
                ", gameScore=" + gameScore +
                '}';
    }

    public String getName() {
        return name;
    }

    public int getTotalStars() {
        return totalStars;
    }

    public void setTotalStars(int totalStars) {
        this.totalStars = totalStars;
    }

    public int getBestScore() {
        return bestScore;
    }

    public void setBestScore(int bestScore) {
        this.bestScore = bestScore;
    }

    public int getGameScore() {
        return gameScore;
    }

    public void setGameScore(int gameScore) {
        this.gameScore = gameScore;
    }

    public Player(String name){
        this.name=name;
    }
}
