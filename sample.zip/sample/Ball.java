package sample;

import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;

public class Ball implements Serializable {
    private transient Circle ball;
    private double ballVelocity;
    private double circle_y;
    private transient MediaPlayer mediaPlayer;
    private static boolean soundBall=true;
    private transient Random rand;
    private int ballCol;
    private boolean immunity;
    private int gravity;
    private boolean firstStarAfterCollision;
//    private double radius;


    public boolean isFirstStarAfterCollision() {
        return firstStarAfterCollision;
    }

    public void setFirstStarAfterCollision(boolean firstStarAfterCollision) {
        this.firstStarAfterCollision = firstStarAfterCollision;
    }

    public int getGravity() {
        return gravity;
    }

    public void setGravity(int gravity) {
        this.gravity = gravity;
    }

    public boolean isImmunity() {
        return immunity;
    }

    public void setImmunity(boolean immunity) {
        this.immunity = immunity;
    }

    public int getBallCol() {
        return ballCol;
    }

    public void setBallCol(int ballCol) {
        this.ballCol=ballCol;
    }

    public void setBall(Circle ball) {
        this.ball = ball;
    }

    public Circle getBall() {
        return ball;
    }


    public double getBallVelocity() {
        return ballVelocity;
    }

    public double getCircle_y() {
        return circle_y;
    }

    public void setCircle_y(double circle_y) {
        this.circle_y = circle_y;
    }

    public MediaPlayer getMediaPlayer() {
        return mediaPlayer;
    }

    public void setMediaPlayer(MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
    }

    public Random getRand() {
        return rand;
    }

    public void setRand(Random rand) {
        this.rand = rand;
    }

    public static boolean isSoundBall() {
        return soundBall;
    }

    public static void setSoundBall(boolean soundBall) {
        Ball.soundBall = soundBall;
    }

    {
        rand=new Random();
        circle_y=525.0f;

        ball = new Circle();
        ball.setCenterX(195.0f);
        ball.setCenterY(circle_y);


        int colSet= rand.nextInt(4);
        this.ballCol=colSet;
        if (colSet==0){
            ball.setFill(Color.YELLOW);
        } else if (colSet==1){
            ball.setFill(Color.DEEPPINK);
        } else if (colSet==2){
            ball.setFill(Color.BLUEVIOLET);
        } else {
            ball.setFill(Color.AQUA);
        }
    }

    public Ball(AnchorPane group,double radius){
        group.getChildren().add(ball);
//        radius=radius1;
        ball.setRadius(radius);
        this.setImmunity(false);
        this.setGravity(2000);
        this.setFirstStarAfterCollision(false);
    }

    public Circle getCircle() {
        return ball;
    }

    public javafx.scene.paint.Paint getColor(){
        return ball.getFill();
    }

    public double getCenter(){
        return circle_y;
    }

    public void setColor(Color col){
        ball.setFill(col);
    }

    public void setBallVelocity(double velocity){
        ballVelocity=velocity;
    }

    public void move(double timeDiff, ArrayList<Obstacle> obList){
        if(circle_y>=525 && ballVelocity<=0) {
            ballVelocity=0;
            return;
        }
        double dist=(ballVelocity * timeDiff) - ((gravity * timeDiff * timeDiff)/2);
        if(circle_y-dist<525/2){
            for (Obstacle obs:obList){
                obs.moveObs(dist);
            }
            ball.setCenterY(525/2);
        }
        else {
            circle_y = circle_y - dist;
            ball.setCenterY(circle_y);
        }

        ballVelocity=ballVelocity-2000*timeDiff;
    }

    public void playJump(){
        if(soundBall){
            URL resource = getClass().getResource("/asset/jump.wav");
            Media media = new Media(resource.toString());
            mediaPlayer = new MediaPlayer(media);
            mediaPlayer.play();
        }
    }
}
