package sample;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.text.Text;

import java.io.*;

public class Last implements Serializable {

    private static Player player;

    public static Player getPlayer() {
        return player;
    }


    public static void setPlayer(Player player1) {
        player = player1;
    }

    @FXML
    private transient ImageView firstSmallRing;
    @FXML
    private transient ImageView secondSmallRing;

    @FXML
    private transient Text bestScore;

    @FXML
    private transient Text finalGameScore;

    @FXML
    private transient Text totalStars;

    private static int score1;


    public void rot(ImageView imv, int mul){
        RotateTransition rotate = new RotateTransition(Duration.millis(3000));
        rotate.setAxis(Rotate.Z_AXIS);
        rotate.setByAngle(360*mul);
        rotate.setCycleCount(Animation.INDEFINITE);
        rotate.setInterpolator(Interpolator.LINEAR);
        //rotate.setAutoReverse(true);
        rotate.setNode(imv);
        rotate.play();
    }

    public void setBestScore(String score){
        bestScore.setText(score);
    }
    public void setFinalGameScore(String score){
        finalGameScore.setText(score);
    }
    public void setTotalStars(String score){
        totalStars.setText(score);
    }

    public void play(String score,String bestScore,String totalStars){
        rot(firstSmallRing,1);
        rot(secondSmallRing,-1);
        setBestScore(bestScore);
        score1=Integer.parseInt(score);
        setFinalGameScore(score);
        setTotalStars(totalStars);

    }

    @FXML
    private void handleLastReturn(ActionEvent event) throws IOException, ClassNotFoundException {
//        readFile();
//        player.setGameScore(score1);
//        if(player.getBestScore()<player.getGameScore()){
//            player.setBestScore(player.getGameScore());
//        }
//        player.setTotalStars(player.getTotalStars()+ player.getGameScore());
//        System.out.println(player);
//        writeToFile(player);
        System.out.println("You clicked return home button ");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("imageRing.fxml"));
        Parent root = loader.load();
        Image myImage=(Image) (loader.getController());
        myImage.play();
        System.out.println(player.getName()+"My name");
        myImage.setPlayer(player);
        Scene scene1 =new Scene(root);
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        home_stage.setScene(scene1);
        home_stage.show();
    }

    @FXML
    private void handleRetry(ActionEvent event) throws Exception {
//        readFile();
//        player.setGameScore(score1);
//        if(player.getBestScore()<player.getGameScore()){
//            player.setBestScore(player.getGameScore());
//        }
//        player.setTotalStars(player.getTotalStars()+ player.getGameScore());
//        System.out.println(player);
//        writeToFile(player);
        System.out.println("You clicked return home button ");
        System.out.println(player.getName()+"HELLOO GYA");
        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene a=new GameStart(10,false,player).initUI(some_stage);
        some_stage.setScene(a);
        some_stage.show();
    }

    @FXML
    private void ActionRestart2(ActionEvent event) throws Exception {
        readFile();
        player.setGameScore(score1);
        if(player.getBestScore()<player.getGameScore()){
            player.setBestScore(player.getGameScore());
        }
        player.setTotalStars(player.getTotalStars()+ player.getGameScore());
        System.out.println(player);
        writeToFile(player);
        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene a=new GameStart(10,false,player).initUI(some_stage);
        some_stage.setScene(a);
        some_stage.show();
    }

    public static void writeToFile(Player p1) throws IOException {
        ObjectOutputStream objectOutputStream=new ObjectOutputStream(new FileOutputStream("PlayerData.txt"));
        if(player.getName().equals("Dhairya")){
            objectOutputStream =new ObjectOutputStream(new FileOutputStream("PlayerDhairya.txt"));
        }
        else if(player.getName().equals("Jishnu")){
            objectOutputStream =new ObjectOutputStream(new FileOutputStream("PlayerJishnu.txt"));
        }
        else if(player.getName().equals("Ishika")){
            objectOutputStream =new ObjectOutputStream(new FileOutputStream("PlayerIshika.txt"));
        }
        else if(player.getName().equals("Rishit")){
            objectOutputStream =new ObjectOutputStream(new FileOutputStream("PlayerRishit.txt"));
        }
        else{
            objectOutputStream =new ObjectOutputStream(new FileOutputStream("PlayerKrish.txt"));
        }
        objectOutputStream.writeObject(p1);
    }
    public static void readFile() throws IOException, ClassNotFoundException {
        ObjectInputStream objectInputStream=null;
        if(player.getName().equals("Dhairya")){
            objectInputStream =new ObjectInputStream((new FileInputStream("PlayerDhairya.txt")));
        }
        else if(player.getName().equals("Jishnu")){
            objectInputStream =new ObjectInputStream((new FileInputStream("PlayerJishnu.txt")));
        }
        else if(player.getName().equals("Ishika")){
            objectInputStream =new ObjectInputStream((new FileInputStream("PlayerIshika.txt")));
        }
        else if(player.getName().equals("Rishit")){
            objectInputStream =new ObjectInputStream((new FileInputStream("PlayerRishit.txt")));
        }
        else{
            objectInputStream =new ObjectInputStream((new FileInputStream("PlayerKrish.txt")));
        }



        Player name=(Player)objectInputStream.readObject();
        player.setTotalStars(name.getTotalStars());
        player.setBestScore(name.getBestScore());
        System.out.println(name);

    }
}
