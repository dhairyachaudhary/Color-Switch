package sample;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.ImageView;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import javax.swing.*;
import java.io.IOException;
import java.io.Serializable;

public class Settings implements Serializable {


    private Player player;

    public Player getPlayer() {
        return player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    @FXML
    private transient Button ReturnButton;



    @FXML
    private transient Button EnableAutoCloud;

    @FXML
    private transient Button SaveButton;

    @FXML
    private transient Button LoadButton;

    @FXML
    private transient Button PlayMusic;

    @FXML
    private transient Button PlaySounds;

    @FXML
    private void goBackFromSettingsAction(ActionEvent event) throws IOException {
        System.out.println("You clicked return home button ");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("imageRing.fxml"));
        Parent root = loader.load();
        Image myImage=(Image) (loader.getController());
        myImage.play();
        Scene scene1 =new Scene(root);
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        home_stage.setScene(scene1);
        home_stage.show();
    }

    @FXML
    private void ActionSound(ActionEvent event){
        if(Star.isSoundStar()){
            PlaySounds.setText("Play Sounds");
            Star.setSoundStar(false);
            ColorSwitcher.setSoundSwitcher(false);
            Ball.setSoundBall(false);
            Obstacle.setSoundObstacle(false);
        }
        else{
            PlaySounds.setText("Stop Sounds");
            Star.setSoundStar(true);
            ColorSwitcher.setSoundSwitcher(true);
            Ball.setSoundBall(true);
            Obstacle.setSoundObstacle(true);
        }
    }

    @FXML
    private void ActionMusic(ActionEvent event){

        if(Image.isMusicGame()){
            PlayMusic.setText("Play Music");
            Image.getMedia().setVolume(0);
            Image.setMusicGame(false);
        }
        else{
            PlayMusic.setText("Stop Music");
            Image.getMedia().setVolume(0.5);
            Image.setMusicGame(true);
        }
    }



}
