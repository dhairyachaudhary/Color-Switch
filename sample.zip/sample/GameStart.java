package sample;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.text.Text;
import java.io.IOException;
import java.io.Serializable;
import java.util.*;
import javafx.animation.AnimationTimer;
import javafx.scene.text.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.effect.Glow;
import javafx.scene.image.ImageView;


public class GameStart extends Application implements EventHandler<KeyEvent>, Serializable {
    private ArrayList<Obstacle> obList;
    private transient Text scoreField;
    private String scoreStr;
    private transient AnchorPane group;
    private transient MyTimer timer;
    private transient Stage stage1;
    private int counter;
    private int score;
    private int numberOfObstacles;
    private double timeDifference;
    public static Ball ball;
    private transient final Random ran;
    private final double distance_bw_obs;
    private GameStart myGame;
    private transient ImageView pImage;
    private transient ImageView background;
    private transient ImageView blur;
    private transient Text pauseField;
    private double ballRadius;
    private static boolean collisionOccurred;
    private static boolean headStartTaken;
    private static Player player;

    public static Player getPlayer() {
        return player;
    }

    public static void setPlayer(Player player) {
        GameStart.player = player;
    }

    public static boolean isHeadStartTaken() {
        return headStartTaken;
    }

    public static void setHeadStartTaken(boolean headStartTaken) {
        GameStart.headStartTaken = headStartTaken;
    }

    public static boolean isCollisionOccurred() {
        return collisionOccurred;
    }

    public static void setCollisionOccurred(boolean collisionOccurred) {
        GameStart.collisionOccurred = collisionOccurred;
    }

    public void setObList(ArrayList<Obstacle> obList) {
        this.obList = obList;
    }

    public void setScoreField(Text scoreField) {
        this.scoreField = scoreField;
    }

    public String getScoreStr() {
        return scoreStr;
    }

    public void setScoreStr(String scoreStr) {
        this.scoreStr = scoreStr;
    }

    public AnchorPane getGroup() {
        return group;
    }

    public void setGroup(AnchorPane group) {
        this.group = group;
    }

    public MyTimer getTimer() {
        return timer;
    }

    public void setTimer(MyTimer timer) {
        this.timer = timer;
    }

    public Stage getStage1() {
        return stage1;
    }

    public void setStage1(Stage stage1) {
        this.stage1 = stage1;
    }

    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getNumberOfObstacles() {
        return numberOfObstacles;
    }

    public void setNumberOfObstacles(int numberOfObstacles) {
        this.numberOfObstacles = numberOfObstacles;
    }

    public double getTimeDifference() {
        return timeDifference;
    }

    public void setTimeDifference(double timeDifference) {
        this.timeDifference = timeDifference;
    }

    public void setBall(Ball ball) {
        this.ball = ball;
    }

    public Random getRan() {
        return ran;
    }

    public double getDistance_bw_obs() {
        return distance_bw_obs;
    }

    public ImageView getpImage() {
        return pImage;
    }

    public void setpImage(ImageView pImage) {
        this.pImage = pImage;
    }

    public ImageView getBackground() {
        return background;
    }

    public void setBackground(ImageView background) {
        this.background = background;
    }

    public ImageView getBlur() {
        return blur;
    }

    public void setBlur(ImageView blur) {
        this.blur = blur;
    }

    public Text getPauseField() {
        return pauseField;
    }

    public void setPauseField(Text pauseField) {
        this.pauseField = pauseField;
    }

    @Override
    public String toString() {
        return "GameStart{" +
                "obList=" + obList +
                ", scoreField=" + scoreField +
                ", scoreStr='" + scoreStr + '\'' +
                ", group=" + group +
                ", timer=" + timer +
                ", stage1=" + stage1 +
                ", counter=" + counter +
                ", score=" + score +
                ", numberOfObstacles=" + numberOfObstacles +
                ", timeDifference=" + timeDifference +
                ", ran=" + ran +
                ", distance_bw_obs=" + distance_bw_obs +
                ", myGame=" + myGame +
                ", pImage=" + pImage +
                ", background=" + background +
                ", blur=" + blur +
                ", pauseField=" + pauseField +
                ", ball=" + ball+
                '}';
    }

    public ArrayList<Obstacle> getObList() {
        return obList;
    }

    public Text getScoreField() {
        return scoreField;
    }

    {
        score=0;
        numberOfObstacles=2;
        ran = new Random();
        counter=0;
        distance_bw_obs=725/2;
    }
    public GameStart(double radius,boolean headStartTaken1,Player player1){
        this.collisionOccurred=false;
        this.ballRadius=radius;
        player=player1;
//        headStartTaken=headStartTaken1;

    }


    @Override
    public void start(Stage stage) throws Exception {
        initUI(stage);
    }

    public GameStart getMyGame() {
        return myGame;
    }

    public void setMyGame(GameStart myGame) {
        this.myGame = myGame;

    }

    public Scene initUI(Stage stage) throws Exception {
        AnchorPane group = new AnchorPane();
        this.group=group;
//        group.setStyle("-fx-background-color: #202020");

        double old_time = System.nanoTime();

        scoreStr=Integer.toString(score);
        scoreField=new Text(scoreStr);
        scoreField.setFont(Font.font("verdana", FontWeight.MEDIUM, FontPosture.REGULAR, 50));
        scoreField.setFill(Color.WHITE);
        scoreField.setX(25);
        scoreField.setY(75);

        background =new ImageView();
        background.setImage(new javafx.scene.image.Image(getClass().getResourceAsStream("/asset/galaxySpace.jpg")));
        background.setX(-300);
        background.setY(-300);
        background.setScaleX(1);
        background.setScaleY(1);

//        background =new ImageView();
//        background.setImage(new javafx.scene.image.Image(getClass().getResourceAsStream("/asset/gamebg.jpg")));
//        background.setX(-150);
//        background.setY(-150);
//        background.setScaleX(0.8);
//        background.setScaleY(1.2);

        blur =new ImageView();
        blur.setImage(new javafx.scene.image.Image(getClass().getResourceAsStream("/asset/blur2.jpg")));
        blur.setX(-0);
        blur.setY(100);
        blur.setScaleX(1);
        blur.setScaleY(1.5);
        blur.setOpacity(0.8);

        pImage = new ImageView();
        pImage.setImage(new javafx.scene.image.Image(getClass().getResourceAsStream("/asset/PImage.png")));
        pImage.setScaleX(0.3);
        pImage.setScaleY(0.3);
        pImage.setX(277);
        pImage.setY(-33);

        pauseField = new Text("");
        pauseField.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 15));
        pauseField.setFill(Color.DARKVIOLET);
        pauseField.setX(314);
        pauseField.setY(87);


        stage1=stage;
        obList=new ArrayList<>();
        group.getChildren().add(background);
        group.getChildren().add(scoreField);
        group.getChildren().add(pauseField);
        group.getChildren().add(pImage);


        ball=new Ball(group,ballRadius);
        timer = new MyTimer(old_time,stage);
        timer.start();
        Obstacle o1=new sample.Circle(group, stage,0,1*distance_bw_obs,timer,stage.getScene());
        o1.getObsColorSwitcher().disappear1();
        Obstacle o2=new sample.Circle(group, stage,0,-0.25*distance_bw_obs,timer,stage.getScene());
        Obstacle o3=new sample.Circle(group, stage,0,-1.5*distance_bw_obs,timer,stage.getScene());
        obList.add(o1);
        obList.add(o2);
        obList.add(o3);
        if(Infinity.isIsFrenzy()){
            group.getChildren().add(blur);
        }
        var scene = new Scene(group, 400, 600);
        scene.setOnKeyPressed(this);
        return scene;
    }

    public void headStart(){
        if(player.getTotalStars()>=15){
            GameStart.setHeadStartTaken(true);
            Glow glow = new Glow();
            glow.setLevel(5);
            ball.getBall().setEffect(glow);
            ball.setGravity(0);
            ball.setBallVelocity(4100);
            player.setTotalStars(player.getTotalStars()-15);
        }
        else{
            GameStart.setHeadStartTaken(false);
            System.out.println("Sorry no headstart available");

        }

    }

    public int getScore() {
        return score;
    }

    public Ball getBall(){
        return ball;
    }

    @Override
    public void handle(KeyEvent keyEvent) {

        System.out.println("TESTING PRINT");
        if(keyEvent.getCode().toString().equals("SPACE")){
            if(Infinity.isIsFrenzy()){
                ball.playJump();
                ball.setGravity(500);
                ball.setBallVelocity(600);
            }
            else{
                ball.playJump();
                ball.setGravity(2000);
                ball.setBallVelocity(510);
            }

        }



        if(keyEvent.getCode().toString().equals("P")){
            timer.stop();
            Parent settings_page_parent= null;

            try {
                settings_page_parent = FXMLLoader.load(getClass().getResource("pause.fxml"));
            } catch (IOException e) {
                e.printStackTrace();
            }
            Scene scenePause =new Scene(settings_page_parent);
            Pause pause=new Pause();
            pause.setPlayer(player);
            pause.setStage(stage1,timer,stage1.getScene());
            stage1.setScene(scenePause);
            stage1.show();
        }

    }

    public class MyTimer extends AnimationTimer {
        private double t_old;
        private transient Stage stage;

        public MyTimer(double t_old, Stage stage) {
            this.stage=stage;
            this.t_old=t_old;
        }

        public double getT_old(){
            return t_old;
        }

        public void setT_old(double t_old1){
            this.t_old=t_old1;
        }

        @Override
        public void handle(long now) {
            timeDifference=(now - t_old)/1000000000;
            t_old=now;

            try {
                doHandle(now, group, stage);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private void doHandle(long now, AnchorPane group, Stage stage) throws Exception {
            ball.move(timeDifference,obList);

            if (counter>numberOfObstacles-1){
                makeNewObs(group, stage);
            }

            for (Obstacle obs: obList) {
                if (ball.getCenter()-10 <= obs.getStar() && !obs.getObsStar().getHit()) {
                    obs.getObsStar().disappear();
                    if(isCollisionOccurred()){
                        ball.setImmunity(false);
                    }
                    score += 1;
                    if(isHeadStartTaken() && score==10){
//                        ball.setBallVelocity(0);
                        setHeadStartTaken(false);
                        ball.getBall().setEffect(new Glow(0));
                    }
                }
            }

//            TopScorers.readBestScores();

            scoreStr=Integer.toString(score);
            scoreField.setText(scoreStr);

            for (Obstacle obs:obList){
                if(ball.getCenter()-10<=obs.getColorWheel() && !obs.getObsColorSwitcher().getHit()){
                    obs.getObsColorSwitcher().disappear(ball, obs);
                    counter++;
                }
            }

            for (Obstacle obs:obList){
//                System.out.println(player.getName());
                obs.checkCollision(GameStart.ball.getCircle(), stage,score,ball,player);
            }
        }
    }

    private Obstacle obGen (int limit, AnchorPane group, Stage stage) throws Exception {
        Obstacle ob;
        Random ran=new Random();
        int index = ran.nextInt(limit);
        if (index == 0) {
            ob = new sample.Circle(group, stage, 0, -1 * distance_bw_obs, timer, stage.getScene());
        } else if (index == 1) {
            ob = new sample.Plus(group, stage, -80, -1.25 * distance_bw_obs, timer, stage.getScene());
        } else if (index == 2) {
            ob = new sample.DottedCircle(group, stage, -10, -1.5 * distance_bw_obs, timer, stage.getScene());
        } else if (index == 3) {
            ob = new sample.Rhombus(group, stage, 0, -1.5 * distance_bw_obs, timer, stage.getScene());
        } else if (index == 4) {
            ob = new sample.TwoPlus(group, stage, -13, -1.25 * distance_bw_obs,timer, stage.getScene());
        } else if (index == 5) {
            ob = new sample.Triangle(group, stage, 0, -1.5 * distance_bw_obs,timer, stage.getScene());
        } else if (index == 6) {
            ob = new sample.RevPlus(group, stage, 75, -1.5 * distance_bw_obs,timer, stage.getScene());
        } else if (index == 7) {
//            ob = new sample.ImbPlus(group, stage, 0, -1.5 * distance_bw_obs,timer, stage.getScene());
            ob = new sample.RevPlus(group, stage, 75, -1.5 * distance_bw_obs,timer, stage.getScene());
        } else if (index == 8) {
            ob = new sample.ImbCircle(group, stage, 0, -1* distance_bw_obs,timer, stage.getScene());
        } else if (index == 9) {
            ob = new sample.CircPlus(group, stage, 195, -1 * distance_bw_obs,timer, stage.getScene());
        } else if (index == 10) {
            ob = new sample.SmallCircle(group, stage, 0, -1 * distance_bw_obs,timer, stage.getScene());
        } else if (index == 11) {
            ob = new sample.CircPlus(group, stage, 195, -1.5 * distance_bw_obs,timer, stage.getScene());
//            ob = new sample.TwoCircle(group, stage, 0, -1 * distance_bw_obs,timer, stage.getScene());
        } else if (index==12){
            ob = new sample.CircPlus(group, stage, 195, -1.5 * distance_bw_obs,timer, stage.getScene());
        } else if (index==13){
            ob = new sample.VertCirc(group, stage, 200, -1.5 * distance_bw_obs,timer, stage.getScene());
        } else {
            ob = new sample.ThreeCirc(group, stage, 0, -1.25 * distance_bw_obs,timer, stage.getScene());
        }
        return ob;
    }

    private void makeNewObs(AnchorPane group, Stage stage) throws Exception {
        int limit;
        if (score<5){
            limit=6;
        } else if (score<9){
            limit=10;
        } else if (score<13){
            limit=12;
        } else {
            limit=15;
        }

        Obstacle ob=obGen(limit, group, stage);
        while (ob.getType().equals(obList.get(obList.size()-1).getType())) {
            ob=obGen(limit, group, stage);
        }

        numberOfObstacles++;
        if (obList.size()>5) {
            obList.remove(0);
        }
        obList.add(ob);
//        group.getChildren().add(blur);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
