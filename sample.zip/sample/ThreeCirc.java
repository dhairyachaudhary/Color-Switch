package sample;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Shape;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.animation.*;
import java.io.IOException;

public class ThreeCirc extends Obstacle {
    private transient Arc a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12;
    private double p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12;

    public Arc getA1() {
        return a1;
    }

    public Arc getA2() {
        return a2;
    }

    public Arc getA3() {
        return a3;
    }

    public Arc getA4() {
        return a4;
    }

    public Arc getA5() {
        return a5;
    }

    public Arc getA6() {
        return a6;
    }

    public Arc getA7() {
        return a7;
    }

    public Arc getA8() {
        return a8;
    }

    public Arc getA9() {
        return a9;
    }

    public Arc getA10() {
        return a10;
    }

    public Arc getA11() {
        return a11;
    }

    public Arc getA12() {
        return a12;
    }

    public double getP1() {
        return p1;
    }

    public double getP2() {
        return p2;
    }

    public double getP3() {
        return p3;
    }

    public double getP4() {
        return p4;
    }

    public double getP5() {
        return p5;
    }

    public double getP6() {
        return p6;
    }

    public double getP7() {
        return p7;
    }

    public double getP8() {
        return p8;
    }

    public double getP9() {
        return p9;
    }

    public double getP10() {
        return p10;
    }

    public double getP11() {
        return p11;
    }

    public double getP12() {
        return p12;
    }

    public void setA1(Arc a1) {
        this.a1 = a1;
    }

    public void setA2(Arc a2) {
        this.a2 = a2;
    }

    public void setA3(Arc a3) {
        this.a3 = a3;
    }

    public void setA4(Arc a4) {
        this.a4 = a4;
    }

    public void setA5(Arc a5) {
        this.a5 = a5;
    }

    public void setA6(Arc a6) {
        this.a6 = a6;
    }

    public void setA7(Arc a7) {
        this.a7 = a7;
    }

    public void setA8(Arc a8) {
        this.a8 = a8;
    }

    public void setA9(Arc a9) {
        this.a9 = a9;
    }

    public void setA10(Arc a10) {
        this.a10 = a10;
    }

    public void setA11(Arc a11) {
        this.a11 = a11;
    }

    public void setA12(Arc a12) {
        this.a12 = a12;
    }

    public ThreeCirc(AnchorPane root, Stage stage, double center_x, double center_y, GameStart.MyTimer timer, Scene scene) throws Exception {
        super(root, stage,timer,scene, "Circle");
        a1 = makeParts(center_y, 180.0f, 100, Color.DEEPPINK);
        a2 = makeParts(center_y, 90.0f, 100, Color.BLUEVIOLET);
        a3 = makeParts(center_y, 0.0f, 100, Color.AQUA);
        a4 = makeParts(center_y, 270.0f, 100, Color.YELLOW);
        a5 = makeParts(center_y, 90.0f, 75, Color.AQUA);
        a6 = makeParts(center_y, 0.0f, 75, Color.BLUEVIOLET);
        a7 = makeParts(center_y, 270.0f, 75, Color.DEEPPINK);
        a8 = makeParts(center_y, 180.0f, 75, Color.YELLOW);
        a9 = makeParts(center_y, 90.0f, 125, Color.AQUA);
        a10 = makeParts(center_y, 0.0f, 125, Color.BLUEVIOLET);
        a11 = makeParts(center_y, 270.0f, 125, Color.DEEPPINK);
        a12 = makeParts(center_y, 180.0f, 125, Color.YELLOW);

        p1=a1.getCenterY();
        p2=a2.getCenterY();
        p3=a3.getCenterY();
        p4=a4.getCenterY();
        p5=a5.getCenterY();
        p6=a6.getCenterY();
        p7=a7.getCenterY();
        p8=a8.getCenterY();
        p9=a9.getCenterY();
        p10=a10.getCenterY();
        p11=a11.getCenterY();
        p12=a12.getCenterY();

        initObstacle(162, center_y-25, 162, center_y+150);
        root.getChildren().addAll(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12);
        this.start(stage);
    }

    @Override
    public double getStar() {
        return a1.getCenterY();
    }

    @Override
    public double getColorWheel(){
        return a1.getCenterY()+175;
    }

    public Arc makeParts(double centery, float startangle, double radius, Color col) {
        Arc a = new Arc();
        a.setCenterX(195);
        a.setCenterY(centery);
        a.setRadiusX(radius);
        a.setRadiusY(radius);
        a.setStartAngle(startangle);
        a.setLength(90.0f);
        a.setStrokeWidth(15);
        a.setFill(Color.TRANSPARENT);
        a.setStroke(col);
        return a;
    }

    public void playAnimation(Arc a, int dir) {
        Timeline animation1 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(a.startAngleProperty(), a.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(4), new KeyValue(a.startAngleProperty(), a.getStartAngle() - (dir*360), Interpolator.LINEAR))

        );
        animation1.setCycleCount(Animation.INDEFINITE);

        animation1.play();
    }

    @Override
    public void start(Stage stage) throws Exception {
        playAnimation(a1, -1);
        playAnimation(a2, -1);
        playAnimation(a3, -1);
        playAnimation(a4, -1);
        playAnimation(a5, 1);
        playAnimation(a6, 1);
        playAnimation(a7, 1);
        playAnimation(a8, 1);
        playAnimation(a9, 1);
        playAnimation(a10, 1);
        playAnimation(a11, 1);
        playAnimation(a12, 1);
    }

    @Override
    public void moveObs(double distance){
        move(distance);
        a1.setCenterY(a1.getCenterY()+distance);
        a2.setCenterY(a2.getCenterY()+distance);
        a3.setCenterY(a3.getCenterY()+distance);
        a4.setCenterY(a4.getCenterY()+distance);
        a5.setCenterY(a1.getCenterY()+distance);
        a6.setCenterY(a2.getCenterY()+distance);
        a7.setCenterY(a3.getCenterY()+distance);
        a8.setCenterY(a4.getCenterY()+distance);
        a9.setCenterY(a1.getCenterY()+distance);
        a10.setCenterY(a2.getCenterY()+distance);
        a11.setCenterY(a3.getCenterY()+distance);
        a12.setCenterY(a4.getCenterY()+distance);

        p1=a1.getCenterY();
        p2=a2.getCenterY();
        p3=a3.getCenterY();
        p4=a4.getCenterY();
        p5=a5.getCenterY();
        p6=a6.getCenterY();
        p7=a7.getCenterY();
        p8=a8.getCenterY();
        p9=a9.getCenterY();
        p10=a10.getCenterY();
        p11=a11.getCenterY();
        p12=a12.getCenterY();
    }


    @Override
    public void checkCollision(javafx.scene.shape.Circle circle, Stage stage,int score,Ball b1,Player player) throws IOException {
        int color;

        if(circle.getFill()==Color.AQUA){
            color=1;
        } else if(circle.getFill()==Color.BLUEVIOLET){
            color=2;
        } else if(circle.getFill()==Color.DEEPPINK){
            color=3;
        } else{
            color=4;
        }

        if(color==4){
            semiIntersect(circle,color,a1,stage,score,b1,player);
            semiIntersect(circle,color,a2,stage,score,b1,player);
            semiIntersect(circle,color,a3,stage,score,b1,player);
            semiIntersect(circle,color,a6,stage,score,b1,player);
            semiIntersect(circle,color,a7,stage,score,b1,player);
            semiIntersect(circle,color,a5,stage,score,b1,player);
            semiIntersect(circle,color,a10,stage,score,b1,player);
            semiIntersect(circle,color,a11,stage,score,b1,player);
            semiIntersect(circle,color,a9,stage,score,b1,player);
        }

        else if(color==3){
            semiIntersect(circle,color,a3,stage,score,b1,player);
            semiIntersect(circle,color,a2,stage,score,b1,player);
            semiIntersect(circle,color,a4,stage,score,b1,player);
            semiIntersect(circle,color,a6,stage,score,b1,player);
            semiIntersect(circle,color,a5,stage,score,b1,player);
            semiIntersect(circle,color,a8,stage,score,b1,player);
            semiIntersect(circle,color,a10,stage,score,b1,player);
            semiIntersect(circle,color,a9,stage,score,b1,player);
            semiIntersect(circle,color,a12,stage,score,b1,player);
        }

        else if(color==2){
            semiIntersect(circle,color,a1,stage,score,b1,player);
            semiIntersect(circle,color,a3,stage,score,b1,player);
            semiIntersect(circle,color,a4,stage,score,b1,player);
            semiIntersect(circle,color,a5,stage,score,b1,player);
            semiIntersect(circle,color,a7,stage,score,b1,player);
            semiIntersect(circle,color,a8,stage,score,b1,player);
            semiIntersect(circle,color,a9,stage,score,b1,player);
            semiIntersect(circle,color,a11,stage,score,b1,player);
            semiIntersect(circle,color,a12,stage,score,b1,player);
        }

        else{
            semiIntersect(circle,color,a1,stage,score,b1,player);
            semiIntersect(circle,color,a2,stage,score,b1,player);
            semiIntersect(circle,color,a4,stage,score,b1,player);
            semiIntersect(circle,color,a6,stage,score,b1,player);
            semiIntersect(circle,color,a7,stage,score,b1,player);
            semiIntersect(circle,color,a8,stage,score,b1,player);
            semiIntersect(circle,color,a10,stage,score,b1,player);
            semiIntersect(circle,color,a11,stage,score,b1,player);
            semiIntersect(circle,color,a12,stage,score,b1,player);
        }
    }
}
