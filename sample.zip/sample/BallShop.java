package sample;

import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.ActionEvent;

import java.io.IOException;

public class BallShop {

    private static Player player;

    public static Player getPlayer() {
        return player;
    }

    public static void setPlayer(Player player1) {
        player = player1;
    }

    public void Action10StarBall(ActionEvent event) throws Exception {
        if(player.getTotalStars()>=1){
            Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            GameStart game1=new GameStart(17,false,player);
            Pause.setMyGame(game1);
            Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
            some_stage.setScene(a);
            some_stage.show();
            player.setTotalStars(player.getTotalStars()-1);
        }
        else{
            Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            GameStart game1=new GameStart(10,false,player);
            Pause.setMyGame(game1);
            Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
            some_stage.setScene(a);
            some_stage.show();
        }



    }
    public void Action20StarBall(ActionEvent event) throws Exception {
        if(player.getTotalStars()>=2){
            Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            GameStart game1=new GameStart(15,false,player);
            Pause.setMyGame(game1);
            Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
            some_stage.setScene(a);
            some_stage.show();
            player.setTotalStars(player.getTotalStars()-1);
        }
        else{
            Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            GameStart game1=new GameStart(10,false,player);
            Pause.setMyGame(game1);
            Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
            some_stage.setScene(a);
            some_stage.show();
        }


    }
    public void Action50StarBall(ActionEvent event) throws Exception {
        if(player.getTotalStars()>=5){
            Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            GameStart game1=new GameStart(13,false,player);
            Pause.setMyGame(game1);
            Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
            some_stage.setScene(a);
            some_stage.show();
            player.setTotalStars(player.getTotalStars()-1);
        }
        else{
            Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            GameStart game1=new GameStart(10,false,player);
            Pause.setMyGame(game1);
            Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
            some_stage.setScene(a);
            some_stage.show();
        }


    }
    public void Action100StarBall(ActionEvent event) throws Exception {
        if(player.getTotalStars()>=10){
            Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            GameStart game1=new GameStart(11,false,player);
            Pause.setMyGame(game1);
            Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
            some_stage.setScene(a);
            some_stage.show();
            player.setTotalStars(player.getTotalStars()-1);
        }
        else{
            Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            GameStart game1=new GameStart(10,false,player);
            Pause.setMyGame(game1);
            Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
            some_stage.setScene(a);
            some_stage.show();
        }


    }
    public void Action150StarBall(ActionEvent event) throws Exception {
        if(player.getTotalStars()>=15){
            Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            GameStart game1=new GameStart(9,false,player);
            Pause.setMyGame(game1);
            Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
            some_stage.setScene(a);
            some_stage.show();
            player.setTotalStars(player.getTotalStars()-1);
        }
        else{
            Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            GameStart game1=new GameStart(10,false,player);
            Pause.setMyGame(game1);
            Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
            some_stage.setScene(a);
            some_stage.show();
        }


    }
    public void Action200StarBall(ActionEvent event) throws Exception {
        if(player.getTotalStars()>=20){
            Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            GameStart game1=new GameStart(7,false,player);
            Pause.setMyGame(game1);
            Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
            some_stage.setScene(a);
            some_stage.show();
            player.setTotalStars(player.getTotalStars()-1);
        }
        else{
            Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            GameStart game1=new GameStart(10,false,player);
            Pause.setMyGame(game1);
            Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
            some_stage.setScene(a);
            some_stage.show();
        }


    }
    public void Action500StarBall(ActionEvent event) throws Exception {
        if(player.getTotalStars()>=50){
            Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            GameStart game1=new GameStart(5,false,player);
            Pause.setMyGame(game1);
            Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
            some_stage.setScene(a);
            some_stage.show();
            player.setTotalStars(player.getTotalStars()-1);
        }
        else{
            Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            GameStart game1=new GameStart(10,false,player);
            Pause.setMyGame(game1);
            Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
            some_stage.setScene(a);
            some_stage.show();
        }

    }

    public void ActionReturn(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("imageRing.fxml"));
        Parent root = loader.load();
        Image myImage=(Image) (loader.getController());
        myImage.play();
        Scene scene1 =new Scene(root);
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        home_stage.setScene(scene1);
        home_stage.show();
    }

}
