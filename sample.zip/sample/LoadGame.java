package sample;

import javafx.scene.text.Text;

import java.util.ArrayList;

public class LoadGame {

    private Ball ball;
    private ArrayList<Obstacle> obList;
    private int score;
    private int numberOfObstacles;

}
