package sample;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.Serializable;

public class Triangle extends Obstacle implements Serializable {
    private transient  Rectangle r1, r2, r3;
    private transient  Polygon t1,t2,t3,t4,t5,t6;
    private transient  final Group g;

    private double pos1;
    private double pos2;
    private double pos3;
    private double pos4;
    private double pos5;
    private double pos6;
    private double pos7;
    private double pos8;
    private double pos9;

    public Rectangle getR1() {
        return r1;
    }

    public void setR1(Rectangle r1) {
        this.r1 = r1;
    }

    public Rectangle getR2() {
        return r2;
    }

    public void setR2(Rectangle r2) {
        this.r2 = r2;
    }

    public Rectangle getR3() {
        return r3;
    }

    public void setR3(Rectangle r3) {
        this.r3 = r3;
    }

    public Polygon getT1() {
        return t1;
    }

    public void setT1(Polygon t1) {
        this.t1 = t1;
    }

    public Polygon getT2() {
        return t2;
    }

    public void setT2(Polygon t2) {
        this.t2 = t2;
    }

    public Polygon getT3() {
        return t3;
    }

    public void setT3(Polygon t3) {
        this.t3 = t3;
    }

    public Polygon getT4() {
        return t4;
    }

    public void setT4(Polygon t4) {
        this.t4 = t4;
    }

    public Polygon getT5() {
        return t5;
    }

    public void setT5(Polygon t5) {
        this.t5 = t5;
    }

    public Polygon getT6() {
        return t6;
    }

    public void setT6(Polygon t6) {
        this.t6 = t6;
    }

    public double getPos1() {
        return pos1;
    }

    public double getPos2() {
        return pos2;
    }

    public double getPos3() {
        return pos3;
    }

    public double getPos4() {
        return pos4;
    }

    public double getPos5() {
        return pos5;
    }

    public double getPos6() {
        return pos6;
    }

    public double getPos7() {
        return pos7;
    }

    public double getPos8() {
        return pos8;
    }

    public double getPos9() {
        return pos9;
    }

    public Triangle(AnchorPane root, Stage stage, double center_x, double center_y, GameStart.MyTimer timer, Scene scene) throws Exception {
        super(root, stage,timer,scene,"Triangle");

        r1=new Rectangle();
        r1.setHeight(150);
        r1.setLayoutX(147-10);
        r1.setLayoutY(115+center_y);
        r1.setRotate(30);
        r1.setWidth(25);
        r1.setFill(Color.AQUA);

        r2=new Rectangle();
        r2.setHeight(150);
        r2.setLayoutX(242-10);
        r2.setLayoutY(115+center_y);
        r2.setRotate(-30);
        r2.setWidth(25);
        r2.setFill(Color.DEEPPINK);

        r3=new Rectangle();
        r3.setHeight(150);
        r3.setLayoutX(194-10);
        r3.setLayoutY(197+center_y);
        r3.setRotate(90);
        r3.setWidth(25);
        r3.setFill(Color.YELLOW);

        t1=new Polygon();
        t1.getPoints().addAll(-42.79129409790039, 41.90371322631836, -17.97125816345215, 40.74338150024414, -39.923545837402344, 2.566340208053589);
        t1.setFill(Color.AQUA);
        t1.setLayoutX(236-10);
        t1.setLayoutY(87+center_y);
        t1.setRotate(30);

        t2=new Polygon();
        t2.getPoints().addAll(-42.791290283203125, 43.75, -18.25, 37.75, -42.791290283203125, -0.5);
        t2.setFill(Color.DEEPPINK);
        t2.setLayoutX(250-10);
        t2.setLayoutY(88+center_y);

        t3=new Polygon();
        t3.getPoints().addAll(-59.75, 43.5, -18.5, 43.5, -17.97125244140625, 19.5);
        t3.setFill(Color.YELLOW);
        t3.setLayoutX(150-10);
        t3.setLayoutY(241+center_y);

        t4=new Polygon();
        t4.getPoints().addAll(25.0, 43.5, -18.5, 43.5, -18.5, 18.5);
        t4.setFill(Color.YELLOW);
        t4.setLayoutX(299-10);
        t4.setLayoutY(241+center_y);

        t5=new Polygon();
        t5.getPoints().addAll(-54.75, 42.5, -12.97125244140625, 18.5, -31.75, 3.5);
        t5.setFill(Color.AQUA);
        t5.setLayoutX(145-10);
        t5.setLayoutY(242+center_y);

        t6=new Polygon();
        t6.getPoints().addAll(-65.75, 25.25, -24.0, 49.5, -49.0, 7.25);
        t6.setFill(Color.DEEPPINK);
        t6.setLayoutX(348-10);
        t6.setLayoutY(235+center_y);

        pos1=r1.getLayoutY();
        pos2=r2.getLayoutY();
        pos3=r3.getLayoutY();
        pos4=t1.getLayoutY();
        pos5=t2.getLayoutY();
        pos6=t3.getLayoutY();
        pos7=t4.getLayoutY();
        pos8=t5.getLayoutY();
        pos9=t6.getLayoutY();

        initObstacle(160, center_y+160, 162, center_y+350);

        g=new Group();
        g.getChildren().addAll(r1,r2,r3,t1,t2,t3,t4,t5,t6);
        root.getChildren().add(g);

        this.start(stage);
    }

    @Override
    public double getStar(){
        return  t6.getLayoutY()-20;
    }

    @Override
    public double getColorWheel(){
        return t6.getLayoutY()+145;
    }

    public void start(Stage stage) throws Exception {
        RotateTransition rotate = new RotateTransition();
        rotate.setAxis(Rotate.Z_AXIS);
        rotate.setByAngle(-3600);
        rotate.setInterpolator(Interpolator.LINEAR);
        rotate.setCycleCount(Animation.INDEFINITE);
        rotate.setDuration(Duration.millis(25000));
        rotate.setNode(g);
        rotate.play();
    }

    public void moveObs(double distance){
        move(distance);
        r1.setLayoutY(r1.getLayoutY()+distance);
        r2.setLayoutY(r2.getLayoutY()+distance);
        r3.setLayoutY(r3.getLayoutY()+distance);
        t1.setLayoutY(t1.getLayoutY()+distance);
        t2.setLayoutY(t2.getLayoutY()+distance);
        t3.setLayoutY(t3.getLayoutY()+distance);
        t4.setLayoutY(t4.getLayoutY()+distance);
        t5.setLayoutY(t5.getLayoutY()+distance);
        t6.setLayoutY(t6.getLayoutY()+distance);

        pos1=r1.getLayoutY();
        pos2=r2.getLayoutY();
        pos3=r3.getLayoutY();
        pos4=t1.getLayoutY();
        pos5=t2.getLayoutY();
        pos6=t3.getLayoutY();
        pos7=t4.getLayoutY();
        pos8=t5.getLayoutY();
        pos9=t6.getLayoutY();
    }

    @Override
    public void checkCollision(javafx.scene.shape.Circle circle, Stage stage,int score,Ball b1,Player player){
        int color;

        if(circle.getFill()==Color.AQUA) {
            color=1;
        } else if(circle.getFill()==Color.BLUEVIOLET) {
            color=2;
        } else if(circle.getFill()==Color.DEEPPINK) {
            color=3;
        } else {
            color=4;
        }

        if(color==4){
            semiIntersect(circle,color,r1,stage,score,b1,player);
            semiIntersect(circle,color,r2,stage,score,b1,player);
            semiIntersect(circle,color,t1,stage,score,b1,player);
            semiIntersect(circle,color,t2,stage,score,b1,player);
            semiIntersect(circle,color,t5,stage,score,b1,player);
            semiIntersect(circle,color,t6,stage,score,b1,player);

        }
        else if(color==3){
            semiIntersect(circle,color,r1,stage,score,b1,player);
            semiIntersect(circle,color,r3,stage,score,b1,player);
            semiIntersect(circle,color,t1,stage,score,b1,player);
            semiIntersect(circle,color,t3,stage,score,b1,player);
            semiIntersect(circle,color,t5,stage,score,b1,player);
            semiIntersect(circle,color,t4,stage,score,b1,player);
        }

        else{
            semiIntersect(circle,color,r3,stage,score,b1,player);
            semiIntersect(circle,color,r2,stage,score,b1,player);
            semiIntersect(circle,color,t3,stage,score,b1,player);
            semiIntersect(circle,color,t2,stage,score,b1,player);
            semiIntersect(circle,color,t4,stage,score,b1,player);
            semiIntersect(circle,color,t6,stage,score,b1,player);
        }
    }
}
