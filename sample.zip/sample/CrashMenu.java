package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.awt.*;
import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;

public class CrashMenu implements Serializable, Initializable , EventHandler<KeyEvent> {

    private transient static Stage stage1;
    private transient static GameStart.MyTimer timer1;
    private transient static Scene scene1;
    private static int score1;
    private static Ball b1;
    private static Player player;

    public static Player getPlayer() {
        return player;
    }

    public static void setPlayer(Player player1) {
        player = player1;
    }

    public void setStage(Stage stage, GameStart.MyTimer timer, Scene scene, int score, Ball ball,Player player1){
        stage1=stage;
        timer1=timer;
        scene1=scene;
        score1=score;
        b1=ball;
        player=player1;
    }

    @FXML
    private void ActionReturnHome2(ActionEvent event) throws IOException, ClassNotFoundException {
        System.out.println("You clicked return home button close");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("last.fxml"));
        Parent root = loader.load();
        writeToFile(player);
        readFile();
        player.setGameScore(score1);
        if(player.getBestScore()<player.getGameScore()){
            player.setBestScore(player.getGameScore());
        }
        player.setTotalStars(player.getTotalStars()+ player.getGameScore());
        System.out.println(player);
        writeToFile(player);
        Last.setPlayer(player);
//        Image myImage=(Image) (loader.getController());
//        myImage.play();
        Last myLast=(Last)(loader.getController());
        String scoreStr=Integer.toString(player.getGameScore());
        String bestScoreStr=Integer.toString(player.getBestScore());
        String totalScoreStr=Integer.toString(player.getTotalStars());
        myLast.play(scoreStr,bestScoreStr,totalScoreStr);
        Scene scene1 =new Scene(root);
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        home_stage.setScene(scene1);
        home_stage.show();
    }

    @FXML
    private void Action100Stars(ActionEvent event) throws IOException {
        if(player.getTotalStars()>=5){
            GameStart.setCollisionOccurred(true);
            b1.setImmunity(true);
            b1.setGravity(0);
            timer1.setT_old(System.nanoTime());
            timer1.start();
            stage1.setScene(scene1);
            stage1.show();
            player.setTotalStars(player.getTotalStars()-5);
        }
        else{
            FXMLLoader loader = new FXMLLoader(getClass().getResource("last.fxml"));
            Parent root = loader.load();
            Last myLast=(Last)(loader.getController());
            String scoreStr=Integer.toString(player.getGameScore());
            String bestScoreStr=Integer.toString(player.getBestScore());
            String totalScoreStr=Integer.toString(player.getTotalStars());
            myLast.play(scoreStr,bestScoreStr,totalScoreStr);
            Scene scene1 =new Scene(root);
            Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
            home_stage.setScene(scene1);
            home_stage.show();

        }

    }


    @FXML
    private void ActionVideo(ActionEvent event) throws IOException {

//        System.out.println("Center before "+GameStart.ball.getCircle().getCenterY());
//        GameStart.ball.getCircle().setCenterY(GameStart.ball.getCircle().getCenterY()+40);
//        GameStart.ball.setCircle_y(GameStart.ball.getCircle_y());
//        System.out.println("Center after "+GameStart.ball.getCircle().getCenterY());
//
//        GameStart.ball=b1;

        GameStart.setCollisionOccurred(true);
        b1.setImmunity(true);
        b1.setGravity(0);
        timer1.setT_old(System.nanoTime());
        timer1.start();
        stage1.setScene(scene1);
        stage1.show();
    }

    @FXML
    private void ActionRestart2(ActionEvent event) throws Exception {
        writeToFile(player);
        readFile();
        player.setGameScore(score1);
        if(player.getBestScore()<player.getGameScore()){
            player.setBestScore(player.getGameScore());
        }
        player.setTotalStars(player.getTotalStars()+ player.getGameScore());
        System.out.println(player);
        writeToFile(player);
        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene a=new GameStart(10,false,player).initUI(some_stage);
        some_stage.setScene(a);
        some_stage.show();
    }

    public static void writeToFile(Player p1) throws IOException {
        ObjectOutputStream objectOutputStream=new ObjectOutputStream(new FileOutputStream("PlayerData.txt"));
        if(player.getName().equals("Dhairya")){
            objectOutputStream =new ObjectOutputStream(new FileOutputStream("PlayerDhairya.txt"));
        }
        else if(player.getName().equals("Jishnu")){
            objectOutputStream =new ObjectOutputStream(new FileOutputStream("PlayerJishnu.txt"));
        }
        else if(player.getName().equals("Ishika")){
            objectOutputStream =new ObjectOutputStream(new FileOutputStream("PlayerIshika.txt"));
        }
        else if(player.getName().equals("Rishit")){
            objectOutputStream =new ObjectOutputStream(new FileOutputStream("PlayerRishit.txt"));
        }
        else{
            objectOutputStream =new ObjectOutputStream(new FileOutputStream("PlayerKrish.txt"));
        }
        objectOutputStream.writeObject(p1);
    }
    public static void readFile() throws IOException, ClassNotFoundException {
        ObjectInputStream objectInputStream=null;
        if(player.getName().equals("Dhairya")){
             objectInputStream =new ObjectInputStream((new FileInputStream("PlayerDhairya.txt")));
        }
        else if(player.getName().equals("Jishnu")){
           objectInputStream =new ObjectInputStream((new FileInputStream("PlayerJishnu.txt")));
        }
        else if(player.getName().equals("Ishika")){
            objectInputStream =new ObjectInputStream((new FileInputStream("PlayerIshika.txt")));
        }
        else if(player.getName().equals("Rishit")){
           objectInputStream =new ObjectInputStream((new FileInputStream("PlayerRishit.txt")));
        }
        else{
           objectInputStream =new ObjectInputStream((new FileInputStream("PlayerKrish.txt")));
        }

        Player name=(Player)objectInputStream.readObject();
        player.setTotalStars(name.getTotalStars());
        player.setBestScore(name.getBestScore());
        System.out.println(name);

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    @Override
    public void handle(KeyEvent keyEvent) {
        if(keyEvent.getCode().toString().equals("SPACE")){
            System.out.println("DO NOTHING");
        }
    }
}
