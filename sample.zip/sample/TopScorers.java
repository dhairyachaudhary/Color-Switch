package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.*;
import java.util.*;

import java.awt.event.KeyEvent;

public class TopScorers implements Serializable {

    @FXML
    private static transient Text FirstPlace;

    public static Text getFirstPlace() {
        return FirstPlace;
    }

    public static Text getSecondPlace() {
        return SecondPlace;
    }

    public static Text getThirdPlace() {
        return ThirdPlace;
    }

    @FXML
    private static transient Text SecondPlace;

    @FXML
    private static transient Text ThirdPlace;
    
    @FXML
    public void ActionReturn(ActionEvent event) throws IOException, ClassNotFoundException {
        System.out.println("You clicked return home button ");
        FXMLLoader loader = new FXMLLoader(getClass().getResource("imageRing.fxml"));
        Parent root = loader.load();
        Image myImage=(Image) (loader.getController());
        myImage.play();
        Scene scene1 =new Scene(root);
        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        home_stage.setScene(scene1);
        home_stage.show();
//        readBestScores();
    }


    public static void readBestScores() throws IOException, ClassNotFoundException {
        int[] bestScores=new int[5];
        ObjectInputStream  objectInputStream1 =new ObjectInputStream((new FileInputStream("PlayerDhairya.txt")));
        Player name1=(Player)objectInputStream1.readObject();
        bestScores[0]=name1.getGameScore();
        ObjectInputStream objectInputStream2 =new ObjectInputStream((new FileInputStream("PlayerJishnu.txt")));
        Player name2=(Player)objectInputStream1.readObject();
        bestScores[1]=name2.getGameScore();
        ObjectInputStream  objectInputStream3 =new ObjectInputStream((new FileInputStream("PlayerIshika.txt")));
        Player name3=(Player)objectInputStream1.readObject();
        bestScores[2]=name3.getGameScore();
        ObjectInputStream objectInputStream4 =new ObjectInputStream((new FileInputStream("PlayerRishit.txt")));
        Player name4=(Player)objectInputStream1.readObject();
        bestScores[3]=name4.getGameScore();
        ObjectInputStream  objectInputStream5 =new ObjectInputStream((new FileInputStream("PlayerKrish.txt")));
        Player name5=(Player)objectInputStream1.readObject();
        bestScores[4]=name5.getGameScore();
        Arrays.sort(bestScores);
//        myImage.getWelcomeMsg().setText("Welcome Dhairya!");
        if(bestScores[0]== name1.getBestScore()){
            //Dhairya first
            TopScorers.getFirstPlace().setText("Dhairya");
        }
        else if(bestScores[0]== name1.getBestScore()){
            //Jishnu first
            TopScorers.getFirstPlace().setText("Jishnu");
        }
        else if(bestScores[0]== name1.getBestScore()){
            //Ishika first
            TopScorers.getFirstPlace().setText("Ishika");
        }
        else if(bestScores[0]== name1.getBestScore()){
            //Rishit first
            TopScorers.getFirstPlace().setText("Rishit");
        }
        else{
            //Krish first
            TopScorers.getFirstPlace().setText("Krish");
        }

        if(bestScores[1]== name1.getBestScore()){
            //Dhairya second
            TopScorers.getSecondPlace().setText("Dhairya");
        }
        else if(bestScores[1]== name1.getBestScore()){
            //Jishnu second
            TopScorers.getSecondPlace().setText("Jishnu");
        }
        else if(bestScores[1]== name1.getBestScore()){
            //Ishika second
            TopScorers.getSecondPlace().setText("Ishika");
        }
        else if(bestScores[1]== name1.getBestScore()){
            //Rishit second
            TopScorers.getSecondPlace().setText("Rishit");
        }
        else{
            //Krish second
            TopScorers.getSecondPlace().setText("Krish");
        }

        if(bestScores[2]== name1.getBestScore()){
            //Dhairya third
            TopScorers.getThirdPlace().setText("Dhairya");
        }
        else if(bestScores[2]== name1.getBestScore()){
            //Jishnu third
            TopScorers.getThirdPlace().setText("Jishnu");
        }
        else if(bestScores[2]== name1.getBestScore()){
            //Ishika third
            TopScorers.getThirdPlace().setText("Ishika");
        }
        else if(bestScores[2]== name1.getBestScore()){
            //Rishit third
            TopScorers.getThirdPlace().setText("Rishit");
        }
        else{
            //Krish third
            TopScorers.getThirdPlace().setText("Krish");
        }





    }

}
