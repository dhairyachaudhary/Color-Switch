package sample;

import javafx.scene.Scene;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import javafx.animation.*;
import java.io.IOException;
import java.io.Serializable;

public class TwoCircle extends Obstacle implements Serializable {
    private transient Arc b1, b2, b3, b4, b5, b6, b7, b8;
    private double p1;
    private double p2;
    private double p3;
    private double p4;
    private double p5;
    private double p6;
    private double p7;
    private double p8;

    public double getP1() {
        return p1;
    }

    public double getP2() {
        return p2;
    }

    public double getP3() {
        return p3;
    }

    public double getP4() {
        return p4;
    }

    public double getP5() {
        return p5;
    }

    public double getP6() {
        return p6;
    }

    public double getP7() {
        return p7;
    }

    public double getP8() {
        return p8;
    }

    public void setB1(Arc b1) {
        this.b1 = b1;
    }

    public void setB2(Arc b2) {
        this.b2 = b2;
    }

    public void setB3(Arc b3) {
        this.b3 = b3;
    }

    public void setB4(Arc b4) {
        this.b4 = b4;
    }

    public void setB5(Arc b5) {
        this.b5 = b5;
    }

    public void setB6(Arc b6) {
        this.b6 = b6;
    }

    public void setB7(Arc b7) {
        this.b7 = b7;
    }

    public void setB8(Arc b8) {
        this.b8 = b8;
    }

    public TwoCircle(AnchorPane root, Stage stage, double center_x, double center_y, GameStart.MyTimer timer, Scene scene) throws Exception {
        super(root, stage,timer,scene,"TwoCircle");

        b1=makeParts(120, center_y,90.0f,Color.AQUA);
        b2=makeParts(120, center_y,0.0f,Color.BLUEVIOLET);
        b3=makeParts(120, center_y,270.0f,Color.DEEPPINK);
        b4=makeParts(120, center_y,180.0f,Color.YELLOW);
        b5=makeParts(270, center_y,180.0f,Color.DEEPPINK);
        b6=makeParts(270, center_y,90.0f,Color.BLUEVIOLET);
        b7=makeParts(270, center_y,0.0f,Color.AQUA);
        b8=makeParts(270, center_y,270.0f,Color.YELLOW);

        p1=b1.getCenterY();
        p2=b2.getCenterY();
        p3=b3.getCenterY();
        p4=b4.getCenterY();
        p5=b5.getCenterY();
        p6=b6.getCenterY();
        p7=b7.getCenterY();
        p8=b8.getCenterY();

        initObstacle(160, center_y-130, 162, center_y+150);
        root.getChildren().addAll(b1,b2,b3,b4,b5,b6,b7,b8);

        this.start(stage);
    }

    public Arc getB1(){
        return b1;
    }

    public Arc getB2(){
        return b2;
    }

    public Arc getB3(){
        return b3;
    }

    public Arc getB4(){
        return b4;
    }

    public Arc getB5(){
        return b5;
    }

    public Arc getB6(){
        return b6;
    }

    public Arc getB7(){
        return b7;
    }

    public Arc getB8(){
        return b8;
    }

    @Override
    public double getStar(){
        return  b1.getCenterY()-130;
    }

    @Override
    public double getColorWheel(){
        return b1.getCenterY()+175;
    }

    public Arc makeParts(double centerx, double centery, float startangle, Color col) {
        Arc a = new Arc();
        a.setCenterX(centerx);
        a.setCenterY(centery);
        a.setRadiusX(70);
        a.setRadiusY(70);
        a.setStartAngle(startangle);
        a.setLength(90.0f);
        a.setStrokeWidth(8);
        a.setFill(Color.TRANSPARENT);
        a.setStroke(col);
        return a;
    }


    public void playAnimation(Arc a, int dir) {
        Timeline animation1 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(a.startAngleProperty(), a.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(4), new KeyValue(a.startAngleProperty(), a.getStartAngle() + (dir*360), Interpolator.LINEAR))

        );
        animation1.setCycleCount(Animation.INDEFINITE);

        animation1.play();
    }

    @Override
    public void start(Stage stage) throws Exception {
        playAnimation(b1,-1);
        playAnimation(b2,-1);
        playAnimation(b3,-1);
        playAnimation(b4,-1);
        playAnimation(b5,1);
        playAnimation(b6,1);
        playAnimation(b7,1);
        playAnimation(b8,1);
    }

    @Override
    public void moveObs(double distance){
        move(distance);
        b1.setCenterY(b1.getCenterY()+distance);
        b2.setCenterY(b2.getCenterY()+distance);
        b3.setCenterY(b3.getCenterY()+distance);
        b4.setCenterY(b4.getCenterY()+distance);
        b5.setCenterY(b5.getCenterY()+distance);
        b6.setCenterY(b6.getCenterY()+distance);
        b7.setCenterY(b7.getCenterY()+distance);
        b8.setCenterY(b8.getCenterY()+distance);

        p1=b1.getCenterY();
        p2=b2.getCenterY();
        p3=b3.getCenterY();
        p4=b4.getCenterY();
        p5=b5.getCenterY();
        p6=b6.getCenterY();
        p7=b7.getCenterY();
        p8=b8.getCenterY();
    }

    @Override
    public void checkCollision(javafx.scene.shape.Circle circle, Stage stage,int score, Ball b1,Player player) throws IOException {
        int color;

        if(circle.getFill()==Color.AQUA){
            color=1;
        }
        else if(circle.getFill()==Color.BLUEVIOLET){
            color=2;
        }
        else if(circle.getFill()==Color.DEEPPINK){
            color=3;
        }
        else{
            color=4;
        }

        if(color==4){
            semiIntersect(circle,color,getB1(),stage,score,b1,player);
            semiIntersect(circle,color,getB2(),stage,score,b1,player);
            semiIntersect(circle,color,getB3(),stage,score,b1,player);

        }
        else if(color==3){
            semiIntersect(circle,color,getB1(),stage,score,b1,player);
            semiIntersect(circle,color,getB2(),stage,score,b1,player);
            semiIntersect(circle,color,getB4(),stage,score,b1,player);
        }
        else if(color==2){
            semiIntersect(circle,color,getB1(),stage,score,b1,player);
            semiIntersect(circle,color,getB3(),stage,score,b1,player);
            semiIntersect(circle,color,getB4(),stage,score,b1,player);

        }
        else{
            semiIntersect(circle,color,getB2(),stage,score,b1,player);
            semiIntersect(circle,color,getB3(),stage,score,b1,player);
            semiIntersect(circle,color,getB4(),stage,score,b1,player);
        }
    }
}
