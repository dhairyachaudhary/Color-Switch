package sample;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.shape.Shape;
import javafx.stage.Stage;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;

public abstract class Obstacle implements Serializable {
    private Star star;
    private ColorSwitcher colorWheel;
    private transient  final AnchorPane root;
    private final String type;
    private transient MediaPlayer mediaPlayer;
    private static boolean soundObstacle=true;
    private transient final Stage stage;
    private transient static Stage stage2;
    private transient GameStart.MyTimer timer1;
    private transient static Scene scene1;


    public GameStart.MyTimer getTimer1() {
        return timer1;
    }

    public void setTimer1(GameStart.MyTimer timer1) {
        this.timer1 = timer1;
    }

    public Star getStar1(){
        return star;
    }
    public ColorSwitcher getColorSwitcher1(){
        return colorWheel;
    }

    public Obstacle(AnchorPane root, Stage stage,GameStart.MyTimer timer,Scene scene, String type){
        this.root=root;
        this.stage=stage;
        this.type=type;
        timer1=timer;
        scene1=scene;
    }

    public static boolean isSoundObstacle() {
        return soundObstacle;
    }

    public static void setSoundObstacle(boolean soundObstacle) {
        Obstacle.soundObstacle = soundObstacle;
    }

    public Star getObsStar(){
        return this.star;
    }

    public ColorSwitcher getObsColorSwitcher(){
        return this.colorWheel;
    }

    public String getType(){
        return this.type;
    }

    public void initObstacle(double sx, double sy, double cx, double cy){
        this.star=new Star(sx,sy,root);
        this.colorWheel=new ColorSwitcher(cx,cy,root);
    }

    public void semiIntersect(javafx.scene.shape.Circle circle, int color, Shape r1, Stage stage1,int score, Ball b1,Player player){

        Shape intersect=Shape.intersect(b1.getCircle(),r1);
        //!b1.isImmunity() || GameStart.isHeadStartTaken()
        if(!GameStart.isHeadStartTaken() && !b1.isImmunity()){
            if(intersect.getBoundsInLocal().getWidth()!=-1){
                System.out.println(GameStart.isHeadStartTaken());
                timer1.stop();
//                System.out.print("I AM HERE ");
                System.out.println(circle.getCenterY());
                Parent settings_page_parent= null;
                try {
                    settings_page_parent = FXMLLoader.load(getClass().getResource("crashMenu.fxml"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
//                CrashMenu cmenu=new CrashMenu();
//                cmenu.setPlayer(player);
                Scene scenepause =new Scene(settings_page_parent);
                obHit();
                CrashMenu c1=new CrashMenu();
//                System.out.println("HIIII "+ player.getName());
                c1.setStage(stage1,timer1,stage1.getScene(),score,b1,player);
                stage1.setScene(scenepause);
                stage1.show();
            }
        }

    }

    public void move(double distance){
        star.move(distance);
        colorWheel.move(distance);
    }

    public void obHit(){
        if(soundObstacle){
            URL resource = getClass().getResource("/asset/breakball1.wav");
            Media media = new Media(resource.toString());
            mediaPlayer = new MediaPlayer(media);
            mediaPlayer.play();
        }
    }

    public abstract void moveObs(double distance);

    public abstract double getStar();

    public abstract double getColorWheel();

    public abstract void checkCollision(javafx.scene.shape.Circle circle, Stage stage,int score,Ball b1,Player player) throws IOException;

    public abstract void start(Stage stage) throws Exception;

}
