package sample;

import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.text.Text;

import java.io.*;
import java.net.URL;

public class Image implements Serializable {
    private transient  static MediaPlayer mediaPlayer;
    private static boolean musicGame=true;
    private static int instance;
    private static Player player;

    public static Player getPlayer() {
        return player;
    }

    public static void setPlayer(Player player1) throws IOException, ClassNotFoundException {
        player = player1;
        ObjectInputStream objectInputStream = null;
        if(player.getName().equals("Dhairya")){
            objectInputStream =new ObjectInputStream((new FileInputStream("PlayerDhairya.txt")));
        }
        else if(player.getName().equals("Jishnu")){
            objectInputStream =new ObjectInputStream((new FileInputStream("PlayerJishnu.txt")));
        }
        else if(player.getName().equals("Ishika")){
            objectInputStream =new ObjectInputStream((new FileInputStream("PlayerIshika.txt")));
        }
        else if(player.getName().equals("Rishit")){
            objectInputStream =new ObjectInputStream((new FileInputStream("PlayerRishit.txt")));
        }
        else{
            objectInputStream =new ObjectInputStream((new FileInputStream("PlayerKrish.txt")));
        }
        Player name=(Player)objectInputStream.readObject();
        player.setTotalStars(name.getTotalStars());
        player.setBestScore(name.getBestScore());
        System.out.println("I AM IN IMAGE SETPLAYER");
    }

    @FXML
    private transient  ImageView ImgOuterRing;

    @FXML
    private transient Text welcomeMsg;

    @FXML
    private transient  ImageView ImgInnerRing;

    @FXML
    private transient  ImageView ImgMiddleRing;

    @FXML
    private transient  ImageView textRing1;

    @FXML
    private transient  ImageView textRing2;
    @FXML
    private transient  ImageView Imgstop;
    @FXML
    private transient  ImageView ImgLeaderboard;
    @FXML
    private transient  Button greyPlayButton;

    @FXML
    private transient  Button SettingsButton;

    @FXML
    private transient  Button InfinityButton;

    @FXML
    public transient  static Button QuestionMarkButton;


    @FXML
    private transient  Button GameModesButton;

    public Text getWelcomeMsg() {
        return welcomeMsg;
    }

    public void setWelcomeMsg(Text welcomeMsg1) {
        welcomeMsg = welcomeMsg1;
    }

    private static URL resource= Image.class.getResource("/asset/track.wav");

    private static MediaPlayer mediaplayer=new MediaPlayer(new Media(resource.toString()));;

    public static MediaPlayer getMedia() {
        return mediaplayer;
    }
    public static void setMedia(MediaPlayer mediaplayer1) {
        Image.mediaplayer = mediaplayer1;
    }

    public static boolean isMusicGame() {
        return musicGame;
    }

    public static void setMusicGame(boolean musicGame) {
        Image.musicGame = musicGame;
    }



    @FXML private transient  javafx.scene.control.Button StopButton;

    {
            if(instance==0){
                Image.getMedia().setVolume(0.5);
            }
        instance++;
    }



    private transient  Stage ps;

    public void setStage(Stage s){
        this.ps=s;
    }

    public void rot(ImageView imv, int mul){
        RotateTransition rotate = new RotateTransition(Duration.millis(3000));
        rotate.setAxis(Rotate.Z_AXIS);
        rotate.setByAngle(360*mul);
        rotate.setCycleCount(Animation.INDEFINITE);
        rotate.setInterpolator(Interpolator.LINEAR);
        //rotate.setAutoReverse(true);
        rotate.setNode(imv);
        rotate.play();
    }

    public void init(Stage s){
        this.ps=s;
    }

    @FXML
    private void handleQuestionAction(ActionEvent event) throws IOException{
        System.out.println("You clicked Questions button ");
        Parent question_page_parent= FXMLLoader.load(getClass().getResource("info.fxml"));
//        FXMLLoader loader = new FXMLLoader(getClass().getResource("settings.fxml"));
        Scene sceneinfo =new Scene(question_page_parent);
        Stage ques_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        ques_stage.setScene(sceneinfo);
        ques_stage.show();
    }

    @FXML
    private void handleInfinityAction(ActionEvent event) throws IOException{
        System.out.println("You clicked Infinity button ");
        Parent infinite_page_parent= FXMLLoader.load(getClass().getResource("infinity.fxml"));
        Infinity infinty1=new Infinity();
        infinty1.setPlayer(player);
//        FXMLLoader loader = new FXMLLoader(getClass().getResource("settings.fxml"));
        Scene sceneinfinity =new Scene(infinite_page_parent);
        Stage infinity_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        infinity_stage.setScene(sceneinfinity);
        infinity_stage.show();
    }

    @FXML
    private void handleSettingsAction(ActionEvent event) throws IOException{
        System.out.println("You clicked Settings button ");
        Parent settings_page_parent= FXMLLoader.load(getClass().getResource("settings.fxml"));
//        FXMLLoader loader = new FXMLLoader(getClass().getResource("settings.fxml"));
        Settings s1=new Settings();
        s1.setPlayer(player);
        Scene scenesettings =new Scene(settings_page_parent);
        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        some_stage.setScene(scenesettings);
        some_stage.show();
    }

    @FXML
    private void handleGameAction(ActionEvent event) throws Exception {
//        System.out.println("You clicked Play button ");
//        Parent settings_page_parent= FXMLLoader.load(getClass().getResource("game.fxml"));
////        FXMLLoader loader = new FXMLLoader(getClass().getResource("settings.fxml"));
//        Scene scenegame =new Scene(settings_page_parent);
//        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
//        some_stage.setScene(scenegame);
//
//        some_stage.show();
//




        //GAMEE MENU GUI
//        System.out.println("You clicked return home button ");
//       FXMLLoader loader = new FXMLLoader(getClass().getResource("game.fxml"));
//
//        Parent root = loader.load();
//
//        Game myGame=(Game) (loader.getController());
//        myGame.play();
//        Scene scenePlay =new Scene(root);
//        Stage home_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
//        home_stage.setScene(scenePlay);
//        home_stage.show();
        String[] arguments = new String[] {"123"};
//        GameStart.main(arguments);

//        Stage s = new Stage();
//       GameStart gs=new GameStart();
//       gs.start(s);

//        gs.start(GameStart.s);

        Infinity.setIsFrenzy(false);
        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        System.out.println(player.getName());
        GameStart game1=new GameStart(10,false,player);
        Pause.setMyGame(game1);
        Scene a=game1.initUI(some_stage);
//        game1.setMyGame(game1);
        some_stage.setScene(a);
        some_stage.show();
//        Application.launch(GameStart.class,arguments);

    }

    @FXML
    private void handleGameModesAction(ActionEvent event) throws IOException{
        System.out.println("You clicked Play button ");
        Parent settings_page_parent= FXMLLoader.load(getClass().getResource("infinity.fxml"));
//        FXMLLoader loader = new FXMLLoader(getClass().getResource("settings.fxml"));
        Infinity infinty1=new Infinity();
        infinty1.setPlayer(player);
        Scene scenegame =new Scene(settings_page_parent);
        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        some_stage.setScene(scenegame);

        some_stage.show();

    }

    @FXML
    private void handleStopAction(ActionEvent event) throws IOException{
        System.out.println("You clicked Stop button ");
//        Parent settings_page_parent= FXMLLoader.load(getClass().getResource("infinity.fxml"));
////        FXMLLoader loader = new FXMLLoader(getClass().getResource("settings.fxml"));
//        Scene scenegame =new Scene(settings_page_parent);
//        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
//        some_stage.setScene(scenegame);
////
////        some_stage.show();
        //this.ps.close();

        Stage stage = (Stage) StopButton.getScene().getWindow();
        stage.close();

    }


    @FXML
    private void handleLeaderBoardAction(ActionEvent event) throws IOException{
        System.out.println("You clicked leaderboard button ");
        Parent settings_page_parent= FXMLLoader.load(getClass().getResource("ballShop.fxml"));
//        FXMLLoader loader = new FXMLLoader(getClass().getResource("settings.fxml"));
        BallShop shop1=new BallShop();
        shop1.setPlayer(player);
        Scene sceneLeader =new Scene(settings_page_parent);
        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        some_stage.setScene(sceneLeader);
        some_stage.show();

    }

    @FXML
    private void ActionresumeSaved(ActionEvent event) throws IOException{
        System.out.println("You clicked resumeSaved button ");
        Parent settings_page_parent= FXMLLoader.load(getClass().getResource("resumeSaved.fxml"));
//      FXMLLoader loader = new FXMLLoader(getClass().getResource("settings.fxml"));
        Scene sceneLeader =new Scene(settings_page_parent);
        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        some_stage.setScene(sceneLeader);
        some_stage.show();

    }

    @FXML
    private void ActionTopScorer(ActionEvent event) throws IOException{
        System.out.println("You clicked resumeSaved button ");
        Parent settings_page_parent= FXMLLoader.load(getClass().getResource("topScorers.fxml"));
//      FXMLLoader loader = new FXMLLoader(getClass().getResource("settings.fxml"));
        Scene sceneLeader =new Scene(settings_page_parent);
        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        some_stage.setScene(sceneLeader);
        some_stage.show();

    }

    @FXML
    public void ActionHeadStart(ActionEvent event) throws Exception {
        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        GameStart game1=new GameStart(10,true,player);
//        GameStart.setHeadStartTaken(true);

        Pause.setMyGame(game1);
        Scene a=game1.initUI(some_stage);
        game1.headStart();
//        game1.setMyGame(game1);
        some_stage.setScene(a);
        some_stage.show();
    }


    @FXML
    public void ActionLogin(ActionEvent event) throws IOException {
        System.out.println("You clicked login button ");
        Parent settings_page_parent= FXMLLoader.load(getClass().getResource("login.fxml"));
//      FXMLLoader loader = new FXMLLoader(getClass().getResource("settings.fxml"));
        Scene sceneLeader =new Scene(settings_page_parent);
        Stage some_stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        some_stage.setScene(sceneLeader);
        some_stage.show();
    }


    public void play() {
        System.out.println("HI");
        System.out.println(6);
        Image.getMedia().setAutoPlay(true);
        Image.getMedia().setCycleCount(MediaPlayer.INDEFINITE);
        rot(ImgInnerRing,1);
        rot(ImgOuterRing,1);
        rot(ImgMiddleRing,-1);
        rot(textRing1,1);
        rot(textRing2,-1);
//        rot(ImgLeaderboard,1);
        rot(Imgstop,-1);
    }
}