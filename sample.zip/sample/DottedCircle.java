package sample;

import javafx.animation.*;
import javafx.animation.PathTransition.OrientationType;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.scene.shape.Circle;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.io.Serializable;

public class DottedCircle extends Obstacle implements Serializable {
    private transient Circle c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20,c21,c22,c23,c24;
    private transient Group g1;
    private double p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16,p17,p18,p19,p20,p21,p22,p23,p24;
    private double center_y;

    public double getP1() {
        return p1;
    }

    public double getP2() {
        return p2;
    }

    public double getP3() {
        return p3;
    }

    public double getP4() {
        return p4;
    }

    public double getP5() {
        return p5;
    }

    public double getP6() {
        return p6;
    }

    public double getP7() {
        return p7;
    }

    public double getP8() {
        return p8;
    }

    public double getP9() {
        return p9;
    }

    public double getP10() {
        return p10;
    }

    public double getP11() {
        return p11;
    }

    public double getP12() {
        return p12;
    }

    public double getP13() {
        return p13;
    }

    public double getP14() {
        return p14;
    }

    public double getP15() {
        return p15;
    }

    public double getP16() {
        return p16;
    }

    public double getP17() {
        return p17;
    }

    public double getP18() {
        return p18;
    }

    public double getP19() {
        return p19;
    }

    public double getP20() {
        return p20;
    }

    public double getP21() {
        return p21;
    }

    public double getP22() {
        return p22;
    }

    public double getP23() {
        return p23;
    }

    public double getP24() {
        return p24;
    }

    public Circle getC1() {
        return c1;
    }

    public void setC1(Circle c1) {
        this.c1 = c1;
    }

    public Circle getC2() {
        return c2;
    }

    public void setC2(Circle c2) {
        this.c2 = c2;
    }

    public Circle getC3() {
        return c3;
    }

    public void setC3(Circle c3) {
        this.c3 = c3;
    }

    public Circle getC4() {
        return c4;
    }

    public void setC4(Circle c4) {
        this.c4 = c4;
    }

    public Circle getC5() {
        return c5;
    }

    public void setC5(Circle c5) {
        this.c5 = c5;
    }

    public Circle getC6() {
        return c6;
    }

    public void setC6(Circle c6) {
        this.c6 = c6;
    }

    public Circle getC7() {
        return c7;
    }

    public void setC7(Circle c7) {
        this.c7 = c7;
    }

    public Circle getC8() {
        return c8;
    }

    public void setC8(Circle c8) {
        this.c8 = c8;
    }

    public Circle getC9() {
        return c9;
    }

    public void setC9(Circle c9) {
        this.c9 = c9;
    }

    public Circle getC10() {
        return c10;
    }

    public void setC10(Circle c10) {
        this.c10 = c10;
    }

    public Circle getC11() {
        return c11;
    }

    public void setC11(Circle c11) {
        this.c11 = c11;
    }

    public Circle getC12() {
        return c12;
    }

    public void setC12(Circle c12) {
        this.c12 = c12;
    }

    public Circle getC13() {
        return c13;
    }

    public void setC13(Circle c13) {
        this.c13 = c13;
    }

    public Circle getC14() {
        return c14;
    }

    public void setC14(Circle c14) {
        this.c14 = c14;
    }

    public Circle getC15() {
        return c15;
    }

    public void setC15(Circle c15) {
        this.c15 = c15;
    }

    public Circle getC16() {
        return c16;
    }

    public void setC16(Circle c16) {
        this.c16 = c16;
    }

    public Circle getC17() {
        return c17;
    }

    public void setC17(Circle c17) {
        this.c17 = c17;
    }

    public Circle getC18() {
        return c18;
    }

    public void setC18(Circle c18) {
        this.c18 = c18;
    }

    public Circle getC19() {
        return c19;
    }

    public void setC19(Circle c19) {
        this.c19 = c19;
    }

    public Circle getC20() {
        return c20;
    }

    public void setC20(Circle c20) {
        this.c20 = c20;
    }

    public Circle getC21() {
        return c21;
    }

    public void setC21(Circle c21) {
        this.c21 = c21;
    }

    public Circle getC22() {
        return c22;
    }

    public void setC22(Circle c22) {
        this.c22 = c22;
    }

    public Circle getC23() {
        return c23;
    }

    public void setC23(Circle c23) {
        this.c23 = c23;
    }

    public Circle getC24() {
        return c24;
    }

    public void setC24(Circle c24) {
        this.c24 = c24;
    }

    public Group getG1() {
        return g1;
    }

    public void setG1(Group g1) {
        this.g1 = g1;
    }

    public double getCenter_y() {
        return center_y;
    }

    public void setCenter_y(double center_y) {
        this.center_y = center_y;
    }

    public DottedCircle(AnchorPane root, Stage stage, double center_x, double center_y, GameStart.MyTimer timer, Scene scene) throws Exception {
        super(root, stage,timer,scene,"DottedCircle");

        c1=new Circle(189+center_x,101+center_y,10);
        c1.setFill(Color.DEEPPINK);
        c2=new Circle(107+center_x,180+center_y,10);
        c2.setFill(Color.DEEPPINK);
        c3=new Circle(166+center_x,107+center_y,10);
        c3.setFill(Color.DEEPPINK);
        c4=new Circle(147+center_x,119+center_y,10);
        c4.setFill(Color.DEEPPINK);
        c5=new Circle(116+center_x,156+center_y,10);
        c5.setFill(Color.DEEPPINK);
        c6=new Circle(131+center_x,135+center_y,10);
        c6.setFill(Color.DEEPPINK);
        c7=new Circle(216+center_x,100+center_y,10);
        c7.setFill(Color.YELLOW);
        c8=new Circle(243+center_x,108+center_y,10);
        c8.setFill(Color.YELLOW);
        c9=new Circle(265+center_x,119+center_y,10);
        c9.setFill(Color.YELLOW);
        c10=new Circle(302+center_x,179+center_y,10);
        c10.setFill(Color.YELLOW);
        c11=new Circle(294+center_x,155+center_y,10);
        c11.setFill(Color.YELLOW);
        c12=new Circle(281+center_x,135+center_y,10);
        c12.setFill(Color.YELLOW);
        c13=new Circle(106+center_x,209+center_y,10);
        c13.setFill(Color.AQUA);
        c14=new Circle(112+center_x,236+center_y,10);
        c14.setFill(Color.AQUA);
        c15=new Circle(124+center_x,259+center_y,10);
        c15.setFill(Color.AQUA);
        c16=new Circle(142+center_x,278+center_y,10);
        c16.setFill(Color.AQUA);
        c17=new Circle(164+center_x,291+center_y,10);
        c17.setFill(Color.AQUA);
        c18=new Circle(189+center_x,301+center_y,10);
        c18.setFill(Color.AQUA);
        c19=new Circle(304+center_x,209+center_y,10);
        c19.setFill(Color.BLUEVIOLET);
        c20=new Circle(298+center_x,236+center_y,10);
        c20.setFill(Color.BLUEVIOLET);
        c21=new Circle(286+center_x,259+center_y,10);
        c21.setFill(Color.BLUEVIOLET);
        c22=new Circle(269+center_x,278+center_y,10);
        c22.setFill(Color.BLUEVIOLET);
        c23=new Circle(244+center_x,291+center_y,10);
        c23.setFill(Color.BLUEVIOLET);
        c24=new Circle(216+center_x,301+center_y,10);
        c24.setFill(Color.BLUEVIOLET);

        p1=c1.getCenterY();
        p2=c2.getCenterY();
        p3=c3.getCenterY();
        p4=c4.getCenterY();
        p5=c5.getCenterY();
        p6=c6.getCenterY();
        p7=c7.getCenterY();
        p8=c8.getCenterY();
        p9=c9.getCenterY();
        p10=c10.getCenterY();
        p11=c11.getCenterY();
        p12=c12.getCenterY();
        p13=c13.getCenterY();
        p14=c14.getCenterY();
        p15=c15.getCenterY();
        p16=c16.getCenterY();
        p17=c17.getCenterY();
        p18=c18.getCenterY();
        p19=c19.getCenterY();
        p20=c20.getCenterY();
        p21=c21.getCenterY();
        p22=c22.getCenterY();
        p23=c23.getCenterY();
        p24=c24.getCenterY();

        this.center_y=center_y;

        initObstacle(160, center_y+170, 162, center_y+350);

        g1=new Group();
        g1.getChildren().addAll(c1, c2, c3, c4, c5, c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20,c21,c22,c23,c24);
        root.getChildren().add(g1);

        this.start(stage);
    }

    @Override
    public double getStar(){
        return c1.getCenterY()+105;
    }

    @Override
    public double getColorWheel(){
        return c1.getCenterY()+275;
    }

    private void init(Stage primaryStage) {
        RotateTransition rotate = new RotateTransition();
        rotate.setAxis(Rotate.Z_AXIS);
        rotate.setByAngle(-3600);
        rotate.setInterpolator(Interpolator.LINEAR);
        rotate.setCycleCount(Animation.INDEFINITE);
        rotate.setDuration(Duration.millis(25000));
        rotate.setNode(g1);
        rotate.play();

        Path path2 = createEllipsePath(300, 200, 100, 100, 0);

        PathTransition pt1 = new PathTransition();
        pt1.setDuration(Duration.seconds(2));
        pt1.setPath(path2);
        pt1.setNode(c1);
        pt1.setOrientation(OrientationType.ORTHOGONAL_TO_TANGENT);
        pt1.setCycleCount(Timeline.INDEFINITE);
    }

    private Path createEllipsePath(double centerX, double centerY, double radiusX, double radiusY, double rotate) {
        ArcTo arcTo = new ArcTo();
        arcTo.setX(centerX - radiusX + 1);
        arcTo.setY(centerY - radiusY);
        arcTo.setSweepFlag(false);
        arcTo.setLargeArcFlag(true);
        arcTo.setRadiusX(radiusX);
        arcTo.setRadiusY(radiusY);
        arcTo.setXAxisRotation(rotate);

        Path path = new Path();
        path.getElements().addAll(
                new MoveTo(centerX-radiusX, centerY-radiusY),
                arcTo,
                new ClosePath());
        return path;
    }
//
//    public void semiIntersect(Circle circle,int color,Circle c1,Stage stage){
//        Shape intersect=Shape.intersect(circle,c1);
//        if(intersect.getBoundsInLocal().getWidth()!=-1){
//            System.out.println("Ball collidied with PINK");
//            stage.close();
//        }
//    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        init(primaryStage);
        primaryStage.show();
    }

    @Override
    public void moveObs(double distance){
        move(distance);
        c1.setCenterY(c1.getCenterY()+distance);
        c2.setCenterY(c2.getCenterY()+distance);
        c3.setCenterY(c3.getCenterY()+distance);
        c4.setCenterY(c4.getCenterY()+distance);
        c5.setCenterY(c5.getCenterY()+distance);
        c6.setCenterY(c6.getCenterY()+distance);
        c7.setCenterY(c7.getCenterY()+distance);
        c8.setCenterY(c8.getCenterY()+distance);

        c9.setCenterY(c9.getCenterY()+distance);
        c10.setCenterY(c10.getCenterY()+distance);
        c11.setCenterY(c11.getCenterY()+distance);
        c12.setCenterY(c12.getCenterY()+distance);
        c13.setCenterY(c13.getCenterY()+distance);
        c14.setCenterY(c14.getCenterY()+distance);
        c15.setCenterY(c15.getCenterY()+distance);
        c16.setCenterY(c16.getCenterY()+distance);
        c17.setCenterY(c17.getCenterY()+distance);
        c18.setCenterY(c18.getCenterY()+distance);
        c19.setCenterY(c19.getCenterY()+distance);

        c20.setCenterY(c20.getCenterY()+distance);
        c21.setCenterY(c21.getCenterY()+distance);
        c22.setCenterY(c22.getCenterY()+distance);
        c23.setCenterY(c23.getCenterY()+distance);
        c24.setCenterY(c24.getCenterY()+distance);

        p1=c1.getCenterY();
        p2=c2.getCenterY();
        p3=c3.getCenterY();
        p4=c4.getCenterY();
        p5=c5.getCenterY();
        p6=c6.getCenterY();
        p7=c7.getCenterY();
        p8=c8.getCenterY();
        p9=c9.getCenterY();
        p10=c10.getCenterY();
        p11=c11.getCenterY();
        p12=c12.getCenterY();
        p13=c13.getCenterY();
        p14=c14.getCenterY();
        p15=c15.getCenterY();
        p16=c16.getCenterY();
        p17=c17.getCenterY();
        p18=c18.getCenterY();
        p19=c19.getCenterY();
        p20=c20.getCenterY();
        p21=c21.getCenterY();
        p22=c22.getCenterY();
        p23=c23.getCenterY();
        p24=c24.getCenterY();
    }

    @Override
    public void checkCollision(javafx.scene.shape.Circle circle, Stage stage,int score, Ball b1,Player player) throws IOException {
        int color;

        if(circle.getFill()==Color.AQUA){
            color=1;
        } else if(circle.getFill()==Color.BLUEVIOLET){
            color=2;
        } else if(circle.getFill()==Color.DEEPPINK){
            color=3;
        } else{
            color=4;
        }

        if(color==4){
            semiIntersect(circle,color,c1,stage,score, b1,player);
            semiIntersect(circle,color,c2,stage,score, b1,player);
            semiIntersect(circle,color,c3,stage,score, b1,player);
            semiIntersect(circle,color,c4,stage,score, b1,player);
            semiIntersect(circle,color,c5,stage,score, b1,player);
            semiIntersect(circle,color,c6,stage,score, b1,player);
            semiIntersect(circle,color,c13,stage,score, b1,player);
            semiIntersect(circle,color,c14,stage,score, b1,player);
            semiIntersect(circle,color,c15,stage,score, b1,player);
            semiIntersect(circle,color,c16,stage,score, b1,player);
            semiIntersect(circle,color,c17,stage,score, b1,player);
            semiIntersect(circle,color,c18,stage,score, b1,player);
            semiIntersect(circle,color,c19,stage,score, b1,player);
            semiIntersect(circle,color,c20,stage,score, b1,player);
            semiIntersect(circle,color,c21,stage,score, b1,player);
            semiIntersect(circle,color,c22,stage,score, b1,player);
            semiIntersect(circle,color,c23,stage,score, b1,player);
            semiIntersect(circle,color,c24,stage,score, b1,player);
        }

        else if(color==3){
            semiIntersect(circle,color,c7,stage,score, b1,player);
            semiIntersect(circle,color,c8,stage,score, b1,player);
            semiIntersect(circle,color,c9,stage,score, b1,player);
            semiIntersect(circle,color,c10,stage,score, b1,player);
            semiIntersect(circle,color,c11,stage,score, b1,player);
            semiIntersect(circle,color,c12,stage,score, b1,player);
            semiIntersect(circle,color,c13,stage,score, b1,player);
            semiIntersect(circle,color,c14,stage,score, b1,player);
            semiIntersect(circle,color,c15,stage,score, b1,player);
            semiIntersect(circle,color,c16,stage,score, b1,player);
            semiIntersect(circle,color,c17,stage,score, b1,player);
            semiIntersect(circle,color,c18,stage,score, b1,player);
            semiIntersect(circle,color,c19,stage,score, b1,player);
            semiIntersect(circle,color,c20,stage,score, b1,player);
            semiIntersect(circle,color,c21,stage,score, b1,player);
            semiIntersect(circle,color,c22,stage,score, b1,player);
            semiIntersect(circle,color,c23,stage,score, b1,player);
            semiIntersect(circle,color,c24,stage,score, b1,player);
        }

        else if(color==2){
            semiIntersect(circle,color,c7,stage,score, b1,player);
            semiIntersect(circle,color,c8,stage,score, b1,player);
            semiIntersect(circle,color,c9,stage,score, b1,player);
            semiIntersect(circle,color,c10,stage,score, b1,player);
            semiIntersect(circle,color,c11,stage,score, b1,player);
            semiIntersect(circle,color,c12,stage,score, b1,player);
            semiIntersect(circle,color,c13,stage,score, b1,player);
            semiIntersect(circle,color,c14,stage,score, b1,player);
            semiIntersect(circle,color,c15,stage,score, b1,player);
            semiIntersect(circle,color,c16,stage,score, b1,player);
            semiIntersect(circle,color,c17,stage,score, b1,player);
            semiIntersect(circle,color,c18,stage,score, b1,player);
            semiIntersect(circle,color,c1,stage,score, b1,player);
            semiIntersect(circle,color,c2,stage,score, b1,player);
            semiIntersect(circle,color,c3,stage,score, b1,player);
            semiIntersect(circle,color,c4,stage,score, b1,player);
            semiIntersect(circle,color,c5,stage,score, b1,player);
            semiIntersect(circle,color,c6,stage,score, b1,player);
        }

        else{
            semiIntersect(circle,color,c7,stage,score, b1,player);
            semiIntersect(circle,color,c8,stage,score, b1,player);
            semiIntersect(circle,color,c9,stage,score, b1,player);
            semiIntersect(circle,color,c10,stage,score, b1,player);
            semiIntersect(circle,color,c11,stage,score, b1,player);
            semiIntersect(circle,color,c12,stage,score, b1,player);
            semiIntersect(circle,color,c19,stage,score, b1,player);
            semiIntersect(circle,color,c20,stage,score, b1,player);
            semiIntersect(circle,color,c21,stage,score, b1,player);
            semiIntersect(circle,color,c22,stage,score, b1,player);
            semiIntersect(circle,color,c23,stage,score, b1,player);
            semiIntersect(circle,color,c24 ,stage,score, b1,player);
            semiIntersect(circle,color,c1,stage,score, b1,player);
            semiIntersect(circle,color,c2,stage,score, b1,player);
            semiIntersect(circle,color,c3,stage,score, b1,player);
            semiIntersect(circle,color,c4,stage,score, b1,player);
            semiIntersect(circle,color,c5,stage,score, b1,player);
            semiIntersect(circle,color,c6,stage,score, b1,player);

        }
    }
}